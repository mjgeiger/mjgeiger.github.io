using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UmassGrader
{
    /// <summary>
    /// helper form to allow users to pick from predefined options
    /// </summary>
    public partial class dlgComboPick : Form
    {
        /// <summary>
        /// list of the items that youcan choose from
        /// </summary>
        object [] myItems;
        /// <summary>
        /// the object that the user selects
        /// </summary>
        public object mySelectedItem;
        public int mySelectedIndex;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="a"></param>
        public dlgComboPick(object [] a)
        {
            myItems = a;
            InitializeComponent();
        }

        private void dlgComboPick_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.AddRange(myItems);
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            mySelectedItem = comboBox1.SelectedItem;
            mySelectedIndex = comboBox1.SelectedIndex;
        }
    }
}