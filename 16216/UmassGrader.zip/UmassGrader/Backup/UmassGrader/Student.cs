using System;
using System.Collections.Generic;
using System.Text;


namespace UmassGrader
{
    /// <summary>
    /// contains all the information about an enrolled student
    /// </summary>
    [Serializable]
    public class Student
    {
        /// <summary>
        /// the username of the student (used to find their folder)
        /// </summary>
        public String userName { get; set; }
        /// <summary>
        /// the first name of the student
        /// </summary>
        public String fName { get; set; }
        /// <summary>
        /// the last name of the student
        /// </summary>
        public String lName { get; set; }
        /// <summary>
        /// enumerated value representing what day the student has lab
        /// </summary>
        public DayOfWeek LabSection { get; set; }
        /// <summary>
        /// is the student enrolled
        /// </summary>
        public bool enrolled { get; set; }
        /// <summary>
        /// Depreciated dont use anymore
        /// </summary>
        public string picturePath { get; set; }

        /// <summary>
        /// construct a fake student
        /// </summary>
        public Student()
            :this("jdoe","Jon","Doe",DayOfWeek.Monday,true)
        { }

        public Student(string uName, string f, string l, DayOfWeek lab, bool en)
        {
            userName = uName;
            fName = f;
            lName = l;
            LabSection = lab;
            enrolled = en;
        }

        /// <summary>
        /// construct student from file stream
        /// </summary>

        public Student(System.IO.StreamReader infile)
            : this()
        {
            if (infile != null) initialize(infile.ReadLine());
        }

        public Student(Student s) // copy constructor
            : this(s.userName, s.fName, s.lName, s.LabSection, s.enrolled)
        { }
            



        /// <summary>
        /// fill in values for student based on string data
        /// </summary>
        /// <param name="datastring">contains all data pertaining to a student (see Class remarks for format)</param>
        public void initialize(string datastring)
        {
            //this method demonstrates the LAME way to do bounds checking... sugestions would be appreciated
            string[] mylst;
            mylst = datastring.Split(',');
            int count = mylst.Length;
            if (count >= 1) userName = mylst[0];
            if (count >= 2) lName = mylst[1];
            if (count >= 3) fName = mylst[2];
            if (count >= 4) LabSection = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), mylst[3]);
            if (count >= 5) enrolled = Boolean.Parse(mylst[4]);
        }



        /// <summary>
        /// gives the Full name of a student
        /// </summary>
        /// <returns>A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.</returns>
        public override string ToString()
        {
            return fullName;
        }


        /// <summary>
        /// is the student withdrawn
        /// </summary>
        public bool Withdrawn
        {
            get { return !enrolled; }
            set { enrolled = !value; }
        }

        /// <summary>
        /// the first and last name of a student
        /// </summary>
        public string fullName
        {
            get { return fName + " " + lName; }
        }
        /// <summary>
        /// is the student in a particular lab section
        /// </summary>
        /// <param name="day">a day of the week</param>
        public bool isSection(DayOfWeek day)
        {
            return day == this.LabSection;
        }
    }

}

