namespace UmassGrader
{
    /// <summary>
    /// this is a dialog box to view/edit/create new assignments
    /// </summary>
    partial class dlgProgram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.OK_Button = new System.Windows.Forms.Button();
            this.TableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.lstData = new System.Windows.Forms.ListBox();
            this.cmsEditDataIn = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.EditDataInfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtDataName = new System.Windows.Forms.TextBox();
            this.cmdRemoveData = new System.Windows.Forms.Button();
            this.cmdAddData = new System.Windows.Forms.Button();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.TableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.GroupBox8 = new System.Windows.Forms.GroupBox();
            this.TableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lstInput = new System.Windows.Forms.ListBox();
            this.cmsEditInput = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.EditFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtInputName = new System.Windows.Forms.TextBox();
            this.cmdAddInput = new System.Windows.Forms.Button();
            this.cmdRemoveInput = new System.Windows.Forms.Button();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.TableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lstOutput = new System.Windows.Forms.ListBox();
            this.txtOutputName = new System.Windows.Forms.TextBox();
            this.cmdRemoveOutput = new System.Windows.Forms.Button();
            this.cmdAddOutput = new System.Windows.Forms.Button();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.tpFiles = new System.Windows.Forms.TabPage();
            this.DTDue4 = new System.Windows.Forms.DateTimePicker();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.TableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.lstSubmit = new System.Windows.Forms.ListBox();
            this.txtSubmitName = new System.Windows.Forms.TextBox();
            this.cmdAddSubmit = new System.Windows.Forms.Button();
            this.cmdRemoveSubmit = new System.Windows.Forms.Button();
            this.TableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.GroupBox6 = new System.Windows.Forms.GroupBox();
            this.txtCustomFlags = new System.Windows.Forms.TextBox();
            this.chkNeedsCompile = new System.Windows.Forms.CheckBox();
            this.tpGeneral = new System.Windows.Forms.TabPage();
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.tpDate = new System.Windows.Forms.TabPage();
            this.GroupBox7 = new System.Windows.Forms.GroupBox();
            this.DTDue5 = new System.Windows.Forms.DateTimePicker();
            this.DTDue1 = new System.Windows.Forms.DateTimePicker();
            this.DTDue3 = new System.Windows.Forms.DateTimePicker();
            this.DTDue2 = new System.Windows.Forms.DateTimePicker();
            this.Cancel_Button = new System.Windows.Forms.Button();
            this.TableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.TableLayoutPanel5.SuspendLayout();
            this.cmsEditDataIn.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.TableLayoutPanel2.SuspendLayout();
            this.GroupBox8.SuspendLayout();
            this.TableLayoutPanel4.SuspendLayout();
            this.cmsEditInput.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.TableLayoutPanel1.SuspendLayout();
            this.tpFiles.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.TableLayoutPanel7.SuspendLayout();
            this.TableLayoutPanel6.SuspendLayout();
            this.GroupBox6.SuspendLayout();
            this.tpGeneral.SuspendLayout();
            this.TabControl1.SuspendLayout();
            this.tpDate.SuspendLayout();
            this.GroupBox7.SuspendLayout();
            this.TableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // OK_Button
            // 
            this.OK_Button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.OK_Button.Location = new System.Drawing.Point(290, 222);
            this.OK_Button.Name = "OK_Button";
            this.OK_Button.Size = new System.Drawing.Size(67, 23);
            this.OK_Button.TabIndex = 0;
            this.OK_Button.Text = "OK";
            this.OK_Button.Click += new System.EventHandler(this.OK_Button_Click);
            // 
            // TableLayoutPanel5
            // 
            this.TableLayoutPanel5.ColumnCount = 2;
            this.TableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel5.Controls.Add(this.lstData, 0, 1);
            this.TableLayoutPanel5.Controls.Add(this.txtDataName, 0, 0);
            this.TableLayoutPanel5.Controls.Add(this.cmdRemoveData, 1, 2);
            this.TableLayoutPanel5.Controls.Add(this.cmdAddData, 0, 2);
            this.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel5.Location = new System.Drawing.Point(3, 16);
            this.TableLayoutPanel5.Name = "TableLayoutPanel5";
            this.TableLayoutPanel5.RowCount = 3;
            this.TableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.TableLayoutPanel5.Size = new System.Drawing.Size(128, 162);
            this.TableLayoutPanel5.TabIndex = 0;
            // 
            // lstData
            // 
            this.TableLayoutPanel5.SetColumnSpan(this.lstData, 2);
            this.lstData.ContextMenuStrip = this.cmsEditDataIn;
            this.lstData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstData.FormattingEnabled = true;
            this.lstData.IntegralHeight = false;
            this.lstData.Location = new System.Drawing.Point(3, 29);
            this.lstData.Name = "lstData";
            this.lstData.Size = new System.Drawing.Size(122, 101);
            this.lstData.TabIndex = 7;
            // 
            // cmsEditDataIn
            // 
            this.cmsEditDataIn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EditDataInfileToolStripMenuItem});
            this.cmsEditDataIn.Name = "cmsEditDataIn";
            this.cmsEditDataIn.Size = new System.Drawing.Size(155, 26);
            // 
            // EditDataInfileToolStripMenuItem
            // 
            this.EditDataInfileToolStripMenuItem.Name = "EditDataInfileToolStripMenuItem";
            this.EditDataInfileToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.EditDataInfileToolStripMenuItem.Text = "edit Data infile";
            this.EditDataInfileToolStripMenuItem.Click += new System.EventHandler(this.EditDataInfileToolStripMenuItem_Click);
            // 
            // txtDataName
            // 
            this.TableLayoutPanel5.SetColumnSpan(this.txtDataName, 2);
            this.txtDataName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDataName.Location = new System.Drawing.Point(3, 3);
            this.txtDataName.Name = "txtDataName";
            this.txtDataName.Size = new System.Drawing.Size(122, 20);
            this.txtDataName.TabIndex = 5;
            // 
            // cmdRemoveData
            // 
            this.cmdRemoveData.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdRemoveData.Location = new System.Drawing.Point(67, 136);
            this.cmdRemoveData.Name = "cmdRemoveData";
            this.cmdRemoveData.Size = new System.Drawing.Size(58, 23);
            this.cmdRemoveData.TabIndex = 8;
            this.cmdRemoveData.Text = "Remove";
            this.cmdRemoveData.UseVisualStyleBackColor = true;
            this.cmdRemoveData.Click += new System.EventHandler(this.cmdRemoveData_Click);
            // 
            // cmdAddData
            // 
            this.cmdAddData.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdAddData.Location = new System.Drawing.Point(3, 136);
            this.cmdAddData.Name = "cmdAddData";
            this.cmdAddData.Size = new System.Drawing.Size(58, 23);
            this.cmdAddData.TabIndex = 6;
            this.cmdAddData.Text = "Add";
            this.cmdAddData.UseVisualStyleBackColor = true;
            this.cmdAddData.Click += new System.EventHandler(this.cmdAddData_Click);
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.TableLayoutPanel5);
            this.GroupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupBox4.Location = new System.Drawing.Point(143, 3);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(134, 181);
            this.GroupBox4.TabIndex = 12;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Data Input File Names";
            // 
            // TableLayoutPanel2
            // 
            this.TableLayoutPanel2.ColumnCount = 3;
            this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.TableLayoutPanel2.Controls.Add(this.GroupBox4, 0, 0);
            this.TableLayoutPanel2.Controls.Add(this.GroupBox8, 0, 0);
            this.TableLayoutPanel2.Controls.Add(this.GroupBox5, 2, 0);
            this.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.TableLayoutPanel2.Name = "TableLayoutPanel2";
            this.TableLayoutPanel2.RowCount = 1;
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel2.Size = new System.Drawing.Size(420, 187);
            this.TableLayoutPanel2.TabIndex = 13;
            // 
            // GroupBox8
            // 
            this.GroupBox8.Controls.Add(this.TableLayoutPanel4);
            this.GroupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupBox8.Location = new System.Drawing.Point(3, 3);
            this.GroupBox8.Name = "GroupBox8";
            this.GroupBox8.Size = new System.Drawing.Size(134, 181);
            this.GroupBox8.TabIndex = 11;
            this.GroupBox8.TabStop = false;
            this.GroupBox8.Text = "Redirected Input File Names";
            // 
            // TableLayoutPanel4
            // 
            this.TableLayoutPanel4.ColumnCount = 2;
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel4.Controls.Add(this.lstInput, 0, 1);
            this.TableLayoutPanel4.Controls.Add(this.txtInputName, 0, 0);
            this.TableLayoutPanel4.Controls.Add(this.cmdAddInput, 0, 2);
            this.TableLayoutPanel4.Controls.Add(this.cmdRemoveInput, 1, 2);
            this.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel4.Location = new System.Drawing.Point(3, 16);
            this.TableLayoutPanel4.Name = "TableLayoutPanel4";
            this.TableLayoutPanel4.RowCount = 3;
            this.TableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.TableLayoutPanel4.Size = new System.Drawing.Size(128, 162);
            this.TableLayoutPanel4.TabIndex = 10;
            // 
            // lstInput
            // 
            this.TableLayoutPanel4.SetColumnSpan(this.lstInput, 2);
            this.lstInput.ContextMenuStrip = this.cmsEditInput;
            this.lstInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstInput.FormattingEnabled = true;
            this.lstInput.IntegralHeight = false;
            this.lstInput.Location = new System.Drawing.Point(3, 29);
            this.lstInput.Name = "lstInput";
            this.lstInput.Size = new System.Drawing.Size(122, 101);
            this.lstInput.TabIndex = 3;
            // 
            // cmsEditInput
            // 
            this.cmsEditInput.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EditFileToolStripMenuItem});
            this.cmsEditInput.Name = "ContextMenuStrip1";
            this.cmsEditInput.Size = new System.Drawing.Size(178, 26);
            // 
            // EditFileToolStripMenuItem
            // 
            this.EditFileToolStripMenuItem.Name = "EditFileToolStripMenuItem";
            this.EditFileToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.EditFileToolStripMenuItem.Text = "Edit Redirected File";
            this.EditFileToolStripMenuItem.Click += new System.EventHandler(this.EditFileToolStripMenuItem_Click);
            // 
            // txtInputName
            // 
            this.TableLayoutPanel4.SetColumnSpan(this.txtInputName, 2);
            this.txtInputName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtInputName.Location = new System.Drawing.Point(3, 3);
            this.txtInputName.Name = "txtInputName";
            this.txtInputName.Size = new System.Drawing.Size(122, 20);
            this.txtInputName.TabIndex = 1;
            // 
            // cmdAddInput
            // 
            this.cmdAddInput.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdAddInput.Location = new System.Drawing.Point(3, 136);
            this.cmdAddInput.Name = "cmdAddInput";
            this.cmdAddInput.Size = new System.Drawing.Size(58, 23);
            this.cmdAddInput.TabIndex = 2;
            this.cmdAddInput.Text = "Add";
            this.cmdAddInput.UseVisualStyleBackColor = true;
            this.cmdAddInput.Click += new System.EventHandler(this.cmdAddInput_Click);
            // 
            // cmdRemoveInput
            // 
            this.cmdRemoveInput.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdRemoveInput.Location = new System.Drawing.Point(67, 136);
            this.cmdRemoveInput.Name = "cmdRemoveInput";
            this.cmdRemoveInput.Size = new System.Drawing.Size(58, 23);
            this.cmdRemoveInput.TabIndex = 4;
            this.cmdRemoveInput.Text = "Remove";
            this.cmdRemoveInput.UseVisualStyleBackColor = true;
            this.cmdRemoveInput.Click += new System.EventHandler(this.cmdRemoveInput_Click);
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.TableLayoutPanel1);
            this.GroupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupBox5.Location = new System.Drawing.Point(283, 3);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(134, 181);
            this.GroupBox5.TabIndex = 10;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "OutputFile Names";
            // 
            // TableLayoutPanel1
            // 
            this.TableLayoutPanel1.ColumnCount = 2;
            this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel1.Controls.Add(this.lstOutput, 0, 1);
            this.TableLayoutPanel1.Controls.Add(this.txtOutputName, 0, 0);
            this.TableLayoutPanel1.Controls.Add(this.cmdRemoveOutput, 1, 2);
            this.TableLayoutPanel1.Controls.Add(this.cmdAddOutput, 0, 2);
            this.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel1.Location = new System.Drawing.Point(3, 16);
            this.TableLayoutPanel1.Name = "TableLayoutPanel1";
            this.TableLayoutPanel1.RowCount = 3;
            this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.TableLayoutPanel1.Size = new System.Drawing.Size(128, 162);
            this.TableLayoutPanel1.TabIndex = 0;
            // 
            // lstOutput
            // 
            this.TableLayoutPanel1.SetColumnSpan(this.lstOutput, 2);
            this.lstOutput.ContextMenuStrip = this.cmsEditInput;
            this.lstOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstOutput.FormattingEnabled = true;
            this.lstOutput.IntegralHeight = false;
            this.lstOutput.Location = new System.Drawing.Point(3, 29);
            this.lstOutput.Name = "lstOutput";
            this.lstOutput.Size = new System.Drawing.Size(122, 101);
            this.lstOutput.TabIndex = 11;
            // 
            // txtOutputName
            // 
            this.TableLayoutPanel1.SetColumnSpan(this.txtOutputName, 2);
            this.txtOutputName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtOutputName.Location = new System.Drawing.Point(3, 3);
            this.txtOutputName.Name = "txtOutputName";
            this.txtOutputName.Size = new System.Drawing.Size(122, 20);
            this.txtOutputName.TabIndex = 9;
            // 
            // cmdRemoveOutput
            // 
            this.cmdRemoveOutput.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdRemoveOutput.Location = new System.Drawing.Point(67, 136);
            this.cmdRemoveOutput.Name = "cmdRemoveOutput";
            this.cmdRemoveOutput.Size = new System.Drawing.Size(58, 23);
            this.cmdRemoveOutput.TabIndex = 12;
            this.cmdRemoveOutput.Text = "Remove";
            this.cmdRemoveOutput.UseVisualStyleBackColor = true;
            this.cmdRemoveOutput.Click += new System.EventHandler(this.cmdRemoveOutput_Click);
            // 
            // cmdAddOutput
            // 
            this.cmdAddOutput.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdAddOutput.Location = new System.Drawing.Point(3, 136);
            this.cmdAddOutput.Name = "cmdAddOutput";
            this.cmdAddOutput.Size = new System.Drawing.Size(58, 23);
            this.cmdAddOutput.TabIndex = 10;
            this.cmdAddOutput.Text = "Add";
            this.cmdAddOutput.UseVisualStyleBackColor = true;
            this.cmdAddOutput.Click += new System.EventHandler(this.cmdAddOutput_Click);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(178, 56);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(35, 13);
            this.Label5.TabIndex = 21;
            this.Label5.Text = "Friday";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(81, 56);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(51, 13);
            this.Label4.TabIndex = 20;
            this.Label4.Text = "Thursday";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(211, 16);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(64, 13);
            this.Label3.TabIndex = 19;
            this.Label3.Text = "Wednesday";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(116, 16);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(48, 13);
            this.Label2.TabIndex = 18;
            this.Label2.Text = "Tuesday";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(20, 16);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(45, 13);
            this.Label1.TabIndex = 17;
            this.Label1.Text = "Monday";
            // 
            // tpFiles
            // 
            this.tpFiles.Controls.Add(this.TableLayoutPanel2);
            this.tpFiles.Location = new System.Drawing.Point(4, 22);
            this.tpFiles.Name = "tpFiles";
            this.tpFiles.Size = new System.Drawing.Size(420, 187);
            this.tpFiles.TabIndex = 2;
            this.tpFiles.Text = "Program I/O";
            this.tpFiles.UseVisualStyleBackColor = true;
            // 
            // DTDue4
            // 
            this.DTDue4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTDue4.Location = new System.Drawing.Point(54, 72);
            this.DTDue4.Name = "DTDue4";
            this.DTDue4.Size = new System.Drawing.Size(88, 20);
            this.DTDue4.TabIndex = 15;
            // 
            // GroupBox1
            // 
            this.TableLayoutPanel6.SetColumnSpan(this.GroupBox1, 2);
            this.GroupBox1.Controls.Add(this.txtFullName);
            this.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.GroupBox1.Location = new System.Drawing.Point(3, 3);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(216, 48);
            this.GroupBox1.TabIndex = 2;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Display Name";
            // 
            // txtFullName
            // 
            this.txtFullName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFullName.Location = new System.Drawing.Point(6, 19);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(204, 20);
            this.txtFullName.TabIndex = 0;
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.TableLayoutPanel7);
            this.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupBox2.Location = new System.Drawing.Point(225, 3);
            this.GroupBox2.Name = "GroupBox2";
            this.TableLayoutPanel6.SetRowSpan(this.GroupBox2, 3);
            this.GroupBox2.Size = new System.Drawing.Size(186, 175);
            this.GroupBox2.TabIndex = 3;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Submit Name";
            // 
            // TableLayoutPanel7
            // 
            this.TableLayoutPanel7.ColumnCount = 2;
            this.TableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel7.Controls.Add(this.lstSubmit, 0, 1);
            this.TableLayoutPanel7.Controls.Add(this.txtSubmitName, 0, 0);
            this.TableLayoutPanel7.Controls.Add(this.cmdAddSubmit, 0, 2);
            this.TableLayoutPanel7.Controls.Add(this.cmdRemoveSubmit, 1, 2);
            this.TableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel7.Location = new System.Drawing.Point(3, 16);
            this.TableLayoutPanel7.Name = "TableLayoutPanel7";
            this.TableLayoutPanel7.RowCount = 3;
            this.TableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutPanel7.Size = new System.Drawing.Size(180, 156);
            this.TableLayoutPanel7.TabIndex = 1;
            // 
            // lstSubmit
            // 
            this.TableLayoutPanel7.SetColumnSpan(this.lstSubmit, 2);
            this.lstSubmit.ContextMenuStrip = this.cmsEditInput;
            this.lstSubmit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstSubmit.FormattingEnabled = true;
            this.lstSubmit.IntegralHeight = false;
            this.lstSubmit.Location = new System.Drawing.Point(3, 29);
            this.lstSubmit.Name = "lstSubmit";
            this.lstSubmit.Size = new System.Drawing.Size(174, 95);
            this.lstSubmit.TabIndex = 9;
            // 
            // txtSubmitName
            // 
            this.TableLayoutPanel7.SetColumnSpan(this.txtSubmitName, 2);
            this.txtSubmitName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSubmitName.Location = new System.Drawing.Point(3, 3);
            this.txtSubmitName.Name = "txtSubmitName";
            this.txtSubmitName.Size = new System.Drawing.Size(174, 20);
            this.txtSubmitName.TabIndex = 0;
            // 
            // cmdAddSubmit
            // 
            this.cmdAddSubmit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdAddSubmit.Location = new System.Drawing.Point(7, 130);
            this.cmdAddSubmit.Name = "cmdAddSubmit";
            this.cmdAddSubmit.Size = new System.Drawing.Size(75, 23);
            this.cmdAddSubmit.TabIndex = 2;
            this.cmdAddSubmit.Text = "Add";
            this.cmdAddSubmit.UseVisualStyleBackColor = true;
            this.cmdAddSubmit.Click += new System.EventHandler(this.cmdAddSubmit_Click);
            // 
            // cmdRemoveSubmit
            // 
            this.cmdRemoveSubmit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmdRemoveSubmit.Location = new System.Drawing.Point(97, 130);
            this.cmdRemoveSubmit.Name = "cmdRemoveSubmit";
            this.cmdRemoveSubmit.Size = new System.Drawing.Size(75, 23);
            this.cmdRemoveSubmit.TabIndex = 3;
            this.cmdRemoveSubmit.Text = "Remove";
            this.cmdRemoveSubmit.UseVisualStyleBackColor = true;
            this.cmdRemoveSubmit.Click += new System.EventHandler(this.cmdRemoveSubmit_Click);
            // 
            // TableLayoutPanel6
            // 
            this.TableLayoutPanel6.ColumnCount = 3;
            this.TableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.TableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.TableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel6.Controls.Add(this.GroupBox1, 0, 0);
            this.TableLayoutPanel6.Controls.Add(this.GroupBox2, 2, 0);
            this.TableLayoutPanel6.Controls.Add(this.GroupBox6, 0, 1);
            this.TableLayoutPanel6.Controls.Add(this.chkNeedsCompile, 0, 2);
            this.TableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.TableLayoutPanel6.Name = "TableLayoutPanel6";
            this.TableLayoutPanel6.RowCount = 3;
            this.TableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutPanel6.Size = new System.Drawing.Size(414, 181);
            this.TableLayoutPanel6.TabIndex = 12;
            // 
            // GroupBox6
            // 
            this.GroupBox6.Controls.Add(this.txtCustomFlags);
            this.GroupBox6.Location = new System.Drawing.Point(3, 57);
            this.GroupBox6.Name = "GroupBox6";
            this.GroupBox6.Size = new System.Drawing.Size(216, 49);
            this.GroupBox6.TabIndex = 11;
            this.GroupBox6.TabStop = false;
            this.GroupBox6.Text = "Custom Project Flags";
            // 
            // txtCustomFlags
            // 
            this.txtCustomFlags.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomFlags.Location = new System.Drawing.Point(6, 19);
            this.txtCustomFlags.Name = "txtCustomFlags";
            this.txtCustomFlags.Size = new System.Drawing.Size(204, 20);
            this.txtCustomFlags.TabIndex = 0;
            // 
            // chkNeedsCompile
            // 
            this.chkNeedsCompile.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chkNeedsCompile.Location = new System.Drawing.Point(3, 139);
            this.chkNeedsCompile.Name = "chkNeedsCompile";
            this.chkNeedsCompile.Size = new System.Drawing.Size(210, 39);
            this.chkNeedsCompile.TabIndex = 5;
            this.chkNeedsCompile.Text = "Needs Compile";
            this.chkNeedsCompile.UseVisualStyleBackColor = true;
            // 
            // tpGeneral
            // 
            this.tpGeneral.Controls.Add(this.TableLayoutPanel6);
            this.tpGeneral.Location = new System.Drawing.Point(4, 22);
            this.tpGeneral.Name = "tpGeneral";
            this.tpGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.tpGeneral.Size = new System.Drawing.Size(420, 187);
            this.tpGeneral.TabIndex = 0;
            this.tpGeneral.Text = "General";
            this.tpGeneral.UseVisualStyleBackColor = true;
            // 
            // TabControl1
            // 
            this.TableLayoutPanel3.SetColumnSpan(this.TabControl1, 3);
            this.TabControl1.Controls.Add(this.tpGeneral);
            this.TabControl1.Controls.Add(this.tpDate);
            this.TabControl1.Controls.Add(this.tpFiles);
            this.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabControl1.Location = new System.Drawing.Point(3, 3);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(428, 213);
            this.TabControl1.TabIndex = 17;
            // 
            // tpDate
            // 
            this.tpDate.Controls.Add(this.GroupBox7);
            this.tpDate.Location = new System.Drawing.Point(4, 22);
            this.tpDate.Name = "tpDate";
            this.tpDate.Padding = new System.Windows.Forms.Padding(3);
            this.tpDate.Size = new System.Drawing.Size(420, 187);
            this.tpDate.TabIndex = 1;
            this.tpDate.Text = "DueDates";
            this.tpDate.UseVisualStyleBackColor = true;
            // 
            // GroupBox7
            // 
            this.GroupBox7.Controls.Add(this.Label5);
            this.GroupBox7.Controls.Add(this.Label4);
            this.GroupBox7.Controls.Add(this.Label3);
            this.GroupBox7.Controls.Add(this.Label2);
            this.GroupBox7.Controls.Add(this.Label1);
            this.GroupBox7.Controls.Add(this.DTDue5);
            this.GroupBox7.Controls.Add(this.DTDue4);
            this.GroupBox7.Controls.Add(this.DTDue1);
            this.GroupBox7.Controls.Add(this.DTDue3);
            this.GroupBox7.Controls.Add(this.DTDue2);
            this.GroupBox7.Location = new System.Drawing.Point(8, 6);
            this.GroupBox7.Name = "GroupBox7";
            this.GroupBox7.Size = new System.Drawing.Size(294, 98);
            this.GroupBox7.TabIndex = 15;
            this.GroupBox7.TabStop = false;
            this.GroupBox7.Text = "Due Dates";
            // 
            // DTDue5
            // 
            this.DTDue5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTDue5.Location = new System.Drawing.Point(153, 72);
            this.DTDue5.Name = "DTDue5";
            this.DTDue5.Size = new System.Drawing.Size(88, 20);
            this.DTDue5.TabIndex = 16;
            // 
            // DTDue1
            // 
            this.DTDue1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTDue1.Location = new System.Drawing.Point(6, 32);
            this.DTDue1.Name = "DTDue1";
            this.DTDue1.Size = new System.Drawing.Size(93, 20);
            this.DTDue1.TabIndex = 12;
            // 
            // DTDue3
            // 
            this.DTDue3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTDue3.Location = new System.Drawing.Point(200, 32);
            this.DTDue3.Name = "DTDue3";
            this.DTDue3.Size = new System.Drawing.Size(88, 20);
            this.DTDue3.TabIndex = 14;
            // 
            // DTDue2
            // 
            this.DTDue2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTDue2.Location = new System.Drawing.Point(105, 32);
            this.DTDue2.Name = "DTDue2";
            this.DTDue2.Size = new System.Drawing.Size(89, 20);
            this.DTDue2.TabIndex = 13;
            // 
            // Cancel_Button
            // 
            this.Cancel_Button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancel_Button.Location = new System.Drawing.Point(364, 222);
            this.Cancel_Button.Name = "Cancel_Button";
            this.Cancel_Button.Size = new System.Drawing.Size(67, 23);
            this.Cancel_Button.TabIndex = 1;
            this.Cancel_Button.Text = "Cancel";
            this.Cancel_Button.Click += new System.EventHandler(this.Cancel_Button_Click);
            // 
            // TableLayoutPanel3
            // 
            this.TableLayoutPanel3.ColumnCount = 3;
            this.TableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 75F));
            this.TableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 74F));
            this.TableLayoutPanel3.Controls.Add(this.TabControl1, 0, 0);
            this.TableLayoutPanel3.Controls.Add(this.Cancel_Button, 2, 1);
            this.TableLayoutPanel3.Controls.Add(this.OK_Button, 1, 1);
            this.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.TableLayoutPanel3.Name = "TableLayoutPanel3";
            this.TableLayoutPanel3.RowCount = 2;
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.TableLayoutPanel3.Size = new System.Drawing.Size(434, 248);
            this.TableLayoutPanel3.TabIndex = 19;
            // 
            // dlgProgram
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 248);
            this.Controls.Add(this.TableLayoutPanel3);
            this.Name = "dlgProgram";
            this.Text = "Form2";
            this.TableLayoutPanel5.ResumeLayout(false);
            this.TableLayoutPanel5.PerformLayout();
            this.cmsEditDataIn.ResumeLayout(false);
            this.GroupBox4.ResumeLayout(false);
            this.TableLayoutPanel2.ResumeLayout(false);
            this.GroupBox8.ResumeLayout(false);
            this.TableLayoutPanel4.ResumeLayout(false);
            this.TableLayoutPanel4.PerformLayout();
            this.cmsEditInput.ResumeLayout(false);
            this.GroupBox5.ResumeLayout(false);
            this.TableLayoutPanel1.ResumeLayout(false);
            this.TableLayoutPanel1.PerformLayout();
            this.tpFiles.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.TableLayoutPanel7.ResumeLayout(false);
            this.TableLayoutPanel7.PerformLayout();
            this.TableLayoutPanel6.ResumeLayout(false);
            this.GroupBox6.ResumeLayout(false);
            this.GroupBox6.PerformLayout();
            this.tpGeneral.ResumeLayout(false);
            this.TabControl1.ResumeLayout(false);
            this.tpDate.ResumeLayout(false);
            this.GroupBox7.ResumeLayout(false);
            this.GroupBox7.PerformLayout();
            this.TableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button OK_Button;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel5;
        internal System.Windows.Forms.ListBox lstData;
        internal System.Windows.Forms.ContextMenuStrip cmsEditDataIn;
        internal System.Windows.Forms.ToolStripMenuItem EditDataInfileToolStripMenuItem;
        internal System.Windows.Forms.TextBox txtDataName;
        internal System.Windows.Forms.Button cmdRemoveData;
        internal System.Windows.Forms.Button cmdAddData;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel2;
        internal System.Windows.Forms.GroupBox GroupBox8;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel4;
        internal System.Windows.Forms.ListBox lstInput;
        internal System.Windows.Forms.ContextMenuStrip cmsEditInput;
        internal System.Windows.Forms.ToolStripMenuItem EditFileToolStripMenuItem;
        internal System.Windows.Forms.TextBox txtInputName;
        internal System.Windows.Forms.Button cmdAddInput;
        internal System.Windows.Forms.Button cmdRemoveInput;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel1;
        internal System.Windows.Forms.ListBox lstOutput;
        internal System.Windows.Forms.TextBox txtOutputName;
        internal System.Windows.Forms.Button cmdRemoveOutput;
        internal System.Windows.Forms.Button cmdAddOutput;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TabPage tpFiles;
        internal System.Windows.Forms.DateTimePicker DTDue4;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel6;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel7;
        internal System.Windows.Forms.ListBox lstSubmit;
        internal System.Windows.Forms.TextBox txtSubmitName;
        internal System.Windows.Forms.Button cmdAddSubmit;
        internal System.Windows.Forms.Button cmdRemoveSubmit;
        internal System.Windows.Forms.GroupBox GroupBox6;
        internal System.Windows.Forms.TextBox txtCustomFlags;
        internal System.Windows.Forms.CheckBox chkNeedsCompile;
        internal System.Windows.Forms.TextBox txtFullName;
        internal System.Windows.Forms.TabPage tpGeneral;
        internal System.Windows.Forms.TabControl TabControl1;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel3;
        internal System.Windows.Forms.Button Cancel_Button;
        internal System.Windows.Forms.TabPage tpDate;
        internal System.Windows.Forms.GroupBox GroupBox7;
        internal System.Windows.Forms.DateTimePicker DTDue5;
        internal System.Windows.Forms.DateTimePicker DTDue1;
        internal System.Windows.Forms.DateTimePicker DTDue3;
        internal System.Windows.Forms.DateTimePicker DTDue2;
    }
}