using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UmassGrader
{
    /// <summary>
    /// a simple implementation of a progress bar. the idea behind this form is that a 
    /// background worker and be linked with the form and report it's progress in a meaningful 
    /// way
    /// </summary>
    public partial class dlgProgress : Form
    {
        /// <summary>
        /// the BackgroundWorker associated with the progres bar
        /// </summary>
        System.ComponentModel.BackgroundWorker mybackground;

        /// <summary>
        /// basic setup of the dialog box
        /// </summary>
        /// <param name="a"> the background worker that the progress bar will be representing</param>
        public dlgProgress(BackgroundWorker a)
        {
            mybackground = a;
            InitializeComponent();
        }

        /// <summary>
        /// sends a signal to the Background worker to stop working.
        /// </summary>
        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
            mybackground.CancelAsync();
        }
        
    }
}