namespace UmassGrader
{
    partial class dlgStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancel_Button = new System.Windows.Forms.Button();
            this.dlgOpenPic = new System.Windows.Forms.OpenFileDialog();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtUname = new System.Windows.Forms.TextBox();
            this.TableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.OK_Button = new System.Windows.Forms.Button();
            this.cmbLabDay = new System.Windows.Forms.ComboBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.chkEnrolled = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.TableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Cancel_Button
            // 
            this.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancel_Button.Location = new System.Drawing.Point(138, 141);
            this.Cancel_Button.Name = "Cancel_Button";
            this.Cancel_Button.Size = new System.Drawing.Size(67, 23);
            this.Cancel_Button.TabIndex = 1;
            this.Cancel_Button.Text = "Cancel";
            this.Cancel_Button.Click += new System.EventHandler(this.Cancel_Button_Click);
            // 
            // dlgOpenPic
            // 
            this.dlgOpenPic.Filter = "image|*.jpg,*.bmp,*.gif|All Files|*.*";
            this.dlgOpenPic.Title = "Choose Picture";
            // 
            // PictureBox1
            // 
            this.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureBox1.Location = new System.Drawing.Point(3, 55);
            this.PictureBox1.Name = "PictureBox1";
            this.TableLayoutPanel2.SetRowSpan(this.PictureBox1, 4);
            this.PictureBox1.Size = new System.Drawing.Size(108, 111);
            this.PictureBox1.TabIndex = 10;
            this.PictureBox1.TabStop = false;
            // 
            // txtUname
            // 
            this.txtUname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtUname.Location = new System.Drawing.Point(3, 3);
            this.txtUname.Name = "txtUname";
            this.txtUname.Size = new System.Drawing.Size(108, 20);
            this.txtUname.TabIndex = 12;
            this.txtUname.Text = "User Name";
            // 
            // TableLayoutPanel2
            // 
            this.TableLayoutPanel2.ColumnCount = 2;
            this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel2.Controls.Add(this.Cancel_Button, 1, 5);
            this.TableLayoutPanel2.Controls.Add(this.PictureBox1, 0, 2);
            this.TableLayoutPanel2.Controls.Add(this.txtUname, 0, 0);
            this.TableLayoutPanel2.Controls.Add(this.OK_Button, 1, 4);
            this.TableLayoutPanel2.Controls.Add(this.cmbLabDay, 1, 3);
            this.TableLayoutPanel2.Controls.Add(this.txtFName, 0, 1);
            this.TableLayoutPanel2.Controls.Add(this.txtLName, 1, 1);
            this.TableLayoutPanel2.Controls.Add(this.chkEnrolled, 1, 2);
            this.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.TableLayoutPanel2.Name = "TableLayoutPanel2";
            this.TableLayoutPanel2.RowCount = 6;
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel2.Size = new System.Drawing.Size(229, 169);
            this.TableLayoutPanel2.TabIndex = 14;
            // 
            // OK_Button
            // 
            this.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.OK_Button.Location = new System.Drawing.Point(138, 108);
            this.OK_Button.Name = "OK_Button";
            this.OK_Button.Size = new System.Drawing.Size(67, 23);
            this.OK_Button.TabIndex = 0;
            this.OK_Button.Text = "OK";
            this.OK_Button.Click += new System.EventHandler(this.OK_Button_Click);
            // 
            // cmbLabDay
            // 
            this.cmbLabDay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbLabDay.FormattingEnabled = true;
            this.cmbLabDay.Items.AddRange(new object[] {
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday"});
            this.cmbLabDay.Location = new System.Drawing.Point(117, 81);
            this.cmbLabDay.Name = "cmbLabDay";
            this.cmbLabDay.Size = new System.Drawing.Size(109, 21);
            this.cmbLabDay.TabIndex = 11;
            this.cmbLabDay.Text = "Monday";
            // 
            // txtFName
            // 
            this.txtFName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtFName.Location = new System.Drawing.Point(3, 29);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(108, 20);
            this.txtFName.TabIndex = 6;
            this.txtFName.Text = "First Name";
            // 
            // txtLName
            // 
            this.txtLName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLName.Location = new System.Drawing.Point(117, 29);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(109, 20);
            this.txtLName.TabIndex = 7;
            this.txtLName.Text = "LastName";
            // 
            // chkEnrolled
            // 
            this.chkEnrolled.AutoSize = true;
            this.chkEnrolled.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkEnrolled.Location = new System.Drawing.Point(117, 55);
            this.chkEnrolled.Name = "chkEnrolled";
            this.chkEnrolled.Size = new System.Drawing.Size(109, 20);
            this.chkEnrolled.TabIndex = 8;
            this.chkEnrolled.Text = "enrolled";
            this.chkEnrolled.UseVisualStyleBackColor = true;
            // 
            // dlgStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(229, 169);
            this.Controls.Add(this.TableLayoutPanel2);
            this.Name = "dlgStudent";
            this.Text = "dlgStudent";
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.TableLayoutPanel2.ResumeLayout(false);
            this.TableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button Cancel_Button;
        internal System.Windows.Forms.OpenFileDialog dlgOpenPic;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel2;
        internal System.Windows.Forms.TextBox txtUname;
        internal System.Windows.Forms.Button OK_Button;
        internal System.Windows.Forms.ComboBox cmbLabDay;
        internal System.Windows.Forms.TextBox txtFName;
        internal System.Windows.Forms.TextBox txtLName;
        internal System.Windows.Forms.CheckBox chkEnrolled;
    }
}