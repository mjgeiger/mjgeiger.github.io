using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Collections;

namespace UmassGrader
{
    public partial class dlgProgram : Form
    {
        /// <summary>
        /// this is the temporary storage for the Assignment that is being edited
        /// </summary>
        private Assignment myProg;
        private Assignment myOriginalProg;

        public Assignment prog
        {
            get { return myProg; }
            set { myProg = value; }
        }

        /// <summary>
        /// initializes the fields of the dialog box with the selected assignment
        /// 
        /// </summary>
        /// <param name="prog">an assignment to be edited. it is possible to pass an Assignment 
        ///  like "new Assinment()". this will give default values that can then be edited by the user</param>
        public dlgProgram(Assignment prog)
        {
            myProg = prog;
            myOriginalProg = prog;
            InitializeComponent();
            //txtFullName.DataBindings.Add("Text", myProg, "dispName");
            //<PHV>chkNeedsCompile.DataBindings.Add("Checked", myProg, "needsCompile");

            //txtCustomFlags.DataBindings.Add("Text", myProg, "compilerFlags");
            lstSubmit.DataSource = myProg.submitList;
            //myProg.dueDateList[0].date

            txtFullName.Text = myProg.dispName;
            txtCustomFlags.Text = myProg.compilerFlags;
            chkNeedsCompile.Checked = myProg.needsCompile;  //<added PHV>
            
            //2nd tab
            //TODO: this currently doesnt work , ive implemented it in the OLD way
            DTDue1.DataBindings.Add("Value", myProg, "DueM");
            DTDue2.DataBindings.Add("Value", myProg, "DueT");
            DTDue3.DataBindings.Add("Value", myProg, "DueW");
            DTDue4.DataBindings.Add("Value", myProg, "DueR");
            DTDue5.DataBindings.Add("Value", myProg, "DueF");


            //3rd tab
            lstInput.DataSource = myProg.inputRedirectList;
            lstData.DataSource = myProg.inputFileList;
            lstOutput.DataSource = myProg.outputFileList;

            // add helpful tooltips for ease of use
            // TODO(Ben Viall): these strings should be rescources to facilitate 
            //multi-language versions.
            ToolTip myToolTip = new ToolTip();
            myToolTip.SetToolTip(this.lstInput, "Program will be run once for each redirected input file");
            myToolTip.SetToolTip(this.lstSubmit, "Grader will attempt to find all these files for each student");
            myToolTip.SetToolTip(this.lstOutput, "The Students program should create these files");
            myToolTip.SetToolTip(this.lstData, "These Files will be provided to the program being graded as input");
            myToolTip.SetToolTip(this.txtCustomFlags, "Insert special compile flags here");
            myToolTip.SetToolTip(this.txtFullName, "this Text will be displayed in the assgnment dropdownbox for selection");
            myToolTip.SetToolTip(this.DTDue1, "sets the DueDate for the lab occuring on this Day of Week");


        }

        private void OK_Button_Click(object sender, EventArgs e)
        {
            // TODO(Ben Viall): validate the input to make sure we dont have problems down the line
            // TODO(Ben Viall): save the Program file
            myProg.dispName = txtFullName.Text;
            myProg.compilerFlags = txtCustomFlags.Text;
            myProg.needsCompile = chkNeedsCompile.Checked; //<added PHV>
            
            DialogResult = System.Windows.Forms.DialogResult.OK;
            //updateAssignment();
            Close();
        }

        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            myProg = myOriginalProg; // overwrite all changes.
            Close();
        }

        private void cmdAddInput_Click(object sender, EventArgs e)
        {
            myProg.inputRedirectList.Add(txtInputName.Text);
            ((CurrencyManager)lstInput.BindingContext[myProg.inputRedirectList]).Refresh();
        }

        private void cmdRemoveInput_Click(object sender, EventArgs e)
        {
            myProg.inputRedirectList.RemoveAt(lstInput.SelectedIndex);
            ((CurrencyManager)lstInput.BindingContext[myProg.inputRedirectList]).Refresh();
        }

        private void cmdAddData_Click(object sender, EventArgs e)
        {
            myProg.inputFileList.Add(txtDataName.Text);
            ((CurrencyManager)lstData.BindingContext[myProg.inputFileList]).Refresh();
        }

        private void cmdRemoveData_Click(object sender, EventArgs e)
        {
            myProg.inputFileList.RemoveAt(lstData.SelectedIndex);
            ((CurrencyManager)lstData.BindingContext[myProg.inputFileList]).Refresh();
        }

        private void cmdAddOutput_Click(object sender, EventArgs e)
        {
            
            myProg.outputFileList.Add(txtOutputName.Text);
            ((CurrencyManager)lstOutput.BindingContext[myProg.outputFileList]).Refresh();
        }

        private void cmdRemoveOutput_Click(object sender, EventArgs e)
        {
            myProg.outputFileList.RemoveAt(lstOutput.SelectedIndex);
            ((CurrencyManager)lstOutput.BindingContext[myProg.outputFileList]).Refresh();
        }

        private void EditFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // TODO(Ben Viall): 
            // if the project hasnt been created dont bother
            // if an the selected index is not valid dont bother
            // otherwise create a master version in the project folder
            // that will be redirected as input
            if (!Directory.Exists(myProg.DestinationDir))
            {
                MessageBox.Show("the project directory doesnt exist yet. come back later.");
                return;
            }

            //updateAssignment();
            if (lstInput.SelectedIndex > -1)
            {
                Process np = new Process();
                np.StartInfo.FileName = "notepad.exe";
                np.StartInfo.Arguments = Form1.myClassSection.pf.inputRedirectPath(myProg, lstInput.SelectedIndex, 0);
                np.Start();
            }

        }

        private void cmdAddSubmit_Click(object sender, EventArgs e)
        {
            myProg.submitList.Add(txtSubmitName.Text);
            ((CurrencyManager)lstSubmit.BindingContext[myProg.submitList]).Refresh();
        }

        private void cmdRemoveSubmit_Click(object sender, EventArgs e)
        {
            myProg.submitList.RemoveAt(lstSubmit.SelectedIndex);
            ((CurrencyManager)lstSubmit.BindingContext[myProg.submitList]).Refresh();
        }
        private void updateAssignment()
        {
            

            //update the program.
            //1st Tab
            myProg.dispName = txtFullName.Text;
            //submit list
            myProg.submitList.Clear();
            IEnumerator pacman = (IEnumerator) lstSubmit.Items.GetEnumerator();
            pacman.Reset();
            while (pacman.MoveNext())
                myProg.submitList.Add((( String) pacman.Current));

            myProg.compilerFlags = txtCustomFlags.Text;
            myProg.needsCompile = chkNeedsCompile.Checked;
            //2nd tab
            myProg.DueM = DTDue1.Value;
            myProg.DueT= DTDue2.Value;
            myProg.DueW = DTDue3.Value;
            myProg.DueR = DTDue4.Value;
            myProg.DueF = DTDue5.Value;
            //3rd tab
            //redirected input
            myProg.inputRedirectList.Clear();
            // myProg.inputRedirectList.AddRange(lstInput.Items)
            pacman = (IEnumerator)lstInput.Items.GetEnumerator();
            pacman.Reset();
            while (pacman.MoveNext())
                myProg.inputRedirectList.Add((( String) pacman.Current));

            //input File List
            myProg.inputFileList.Clear();
            pacman = (IEnumerator)lstData.Items.GetEnumerator();
            pacman.Reset();
            while (pacman.MoveNext())
                myProg.inputFileList.Add((( String) pacman.Current));

            //output file list
            myProg.outputFileList.Clear();
            pacman = (IEnumerator)lstOutput.Items.GetEnumerator();
            pacman.Reset();
            while (pacman.MoveNext())
                myProg.outputFileList.Add((( String) pacman.Current));

        }

        private void EditDataInfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // TODO(Ben Viall): 
            // if the project hasnt been created dont bother
            // if an the selected index is not valid dont bother
            // otherwise create a master version in the project folder
            // that will be redirected as input
            if (!Directory.Exists(myProg.DestinationDir))
            {
                MessageBox.Show("the project directory doesnt exist yet. come back later.");
                return;
            }

            //updateAssignment();
            if (lstData.SelectedIndex > -1)
            {
                Process np = new Process();
                np.StartInfo.FileName = "notepad.exe";
                np.StartInfo.Arguments = Form1.myClassSection.pf.inputDataFilePath( myProg, lstData.SelectedIndex, 0);
                np.Start();
            }
        }


    }
}