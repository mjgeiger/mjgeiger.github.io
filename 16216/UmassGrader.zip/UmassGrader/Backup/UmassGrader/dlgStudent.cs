using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace UmassGrader
{
    /// <summary>
    /// this form allows you to view and edit an enrolled students data
    /// </summary>
    public partial class dlgStudent : Form
    {
        /// <summary>
        /// a temporary storage location for the student being edited
        /// </summary>
        public Student myStu;

        /// <summary>
        /// initialized the fields of the dialog box with the students data
        /// </summary>
        /// <param name="stu"></param>
        public dlgStudent(Student stu)
        {
            myStu = stu;
            InitializeComponent();
            txtUname.Text = myStu.userName;
            txtFName.Text = myStu.fName;
            txtLName.Text = myStu.lName;
            chkEnrolled.Checked = !myStu.Withdrawn;
            cmbLabDay.SelectedItem = myStu.LabSection.ToString();
        }

        /// <summary>
        /// indicated that all changes needed, have been made.
        /// it is safe to update the actual data
        /// </summary>
        private void OK_Button_Click(object sender, EventArgs e)
        {
            myStu.userName = txtUname.Text;
            myStu.fName = txtFName.Text;
            myStu.lName = txtLName.Text;
            myStu.Withdrawn = !chkEnrolled.Checked;
            myStu.LabSection = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), cmbLabDay.SelectedItem.ToString());
            //myStu.PicPath = PictureBox1.ImageLocation
            DialogResult = DialogResult.OK;
            Close();
        }

        /// <summary>
        /// indicates that all changes to the student should be thrown out.
        /// </summary>
        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}