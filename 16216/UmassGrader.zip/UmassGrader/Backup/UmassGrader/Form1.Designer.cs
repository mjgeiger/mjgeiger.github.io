namespace UmassGrader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.FileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LoadProgramDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveProgramListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.LoadListOfStudentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveStudentListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ChooseHomeFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ChoseRemoteFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.SaveSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectAllToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectNoneToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByLabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MondayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TuesdayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.WednesdayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThursdayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FridayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByGradeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectGradeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.txtToolStripGrade = new System.Windows.Forms.ToolStripTextBox();
            this.SelectInversToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectUngradedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StudentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditSelectedStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.WithDrawFromClassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ReenrollSelectedInClassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DisplayAllGradeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GetStudentListFromDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AssignmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddAssignmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditSelectedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.DownloadSourcesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CompileSourcesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GradeSourcesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UploadGradesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ShowtempToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EmailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EmailAssignmentGradeToCheckedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStriptxtEmailFrom = new System.Windows.Forms.ToolStripTextBox();
            this.ToolStriptxtEmailPassword = new System.Windows.Forms.ToolStripTextBox();
            this.MiscToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CopyGradesToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GenerateComparisonDirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GenerateStudentsFromRemoteDirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.launchCmdPromptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblLocalDir = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblRemoteDir = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslblCurrentProg = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslblCurrentStudent = new System.Windows.Forms.ToolStripStatusLabel();
            this.SplitContainer1 = new System.Windows.Forms.SplitContainer();
            this.TableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbProglist = new System.Windows.Forms.ComboBox();
            this.chkListStuList = new System.Windows.Forms.CheckedListBox();
            this.ContextMenuStripSelectBy = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SelectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectNoneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectInverseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectByGradeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.SelectLab1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MondayToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.TuesdayToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.WednesdayToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ThursdayToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.FridayToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectGradedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rerunSelectedStudentONLYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chkShowWithdrawn = new System.Windows.Forms.CheckBox();
            this.chkUseFlags = new System.Windows.Forms.CheckBox();
            this.chkAutoAdvance = new System.Windows.Forms.CheckBox();
            this.chkAutoDelete = new System.Windows.Forms.CheckBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCustFlags = new System.Windows.Forms.TextBox();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.txtProgTimeout = new System.Windows.Forms.TextBox();
            this.SplitContainer2 = new System.Windows.Forms.SplitContainer();
            this.SplitContainer5 = new System.Windows.Forms.SplitContainer();
            this.txtGrade = new System.Windows.Forms.TextBox();
            this.picStuPic = new System.Windows.Forms.PictureBox();
            this.TableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.SplitContainer3 = new System.Windows.Forms.SplitContainer();
            this.TableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.gotoOutput = new System.Windows.Forms.RadioButton();
            this.gotoCompiler = new System.Windows.Forms.RadioButton();
            this.gotoCode = new System.Windows.Forms.RadioButton();
            this.gotoComment = new System.Windows.Forms.RadioButton();
            this.txtMain = new System.Windows.Forms.TextBox();
            this.SplitContainer4 = new System.Windows.Forms.SplitContainer();
            this.TableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.grd25 = new System.Windows.Forms.Button();
            this.contextMenuStripChangeGradeVal = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripTextBoxNewGrade = new System.Windows.Forms.ToolStripTextBox();
            this.grd35 = new System.Windows.Forms.Button();
            this.grd45 = new System.Windows.Forms.Button();
            this.grd55 = new System.Windows.Forms.Button();
            this.grd65 = new System.Windows.Forms.Button();
            this.grd75 = new System.Windows.Forms.Button();
            this.grd85 = new System.Windows.Forms.Button();
            this.grd95 = new System.Windows.Forms.Button();
            this.grd0 = new System.Windows.Forms.Button();
            this.cmdNext = new System.Windows.Forms.Button();
            this.grd10 = new System.Windows.Forms.Button();
            this.grd20 = new System.Windows.Forms.Button();
            this.grd30 = new System.Windows.Forms.Button();
            this.grd40 = new System.Windows.Forms.Button();
            this.grd50 = new System.Windows.Forms.Button();
            this.grd60 = new System.Windows.Forms.Button();
            this.grd70 = new System.Windows.Forms.Button();
            this.grd80 = new System.Windows.Forms.Button();
            this.grd90 = new System.Windows.Forms.Button();
            this.grd100 = new System.Windows.Forms.Button();
            this.cmdPrev = new System.Windows.Forms.Button();
            this.grdCustom = new System.Windows.Forms.TextBox();
            this.lblLate = new System.Windows.Forms.Label();
            this.dlgOpenSettings = new System.Windows.Forms.OpenFileDialog();
            this.bkgDownload = new System.ComponentModel.BackgroundWorker();
            this.bkgCompile = new System.ComponentModel.BackgroundWorker();
            this.bkgUpload = new System.ComponentModel.BackgroundWorker();
            this.dlgSaveProgList = new System.Windows.Forms.SaveFileDialog();
            this.dlgSaveStuList = new System.Windows.Forms.SaveFileDialog();
            this.dlgOpenStudent = new System.Windows.Forms.OpenFileDialog();
            this.dlgOpenProg = new System.Windows.Forms.OpenFileDialog();
            this.fldrLocalDir = new System.Windows.Forms.FolderBrowserDialog();
            this.fldrRemoteDir = new System.Windows.Forms.FolderBrowserDialog();
            this.dlgFindCL = new System.Windows.Forms.OpenFileDialog();
            this.debugStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip1.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.SplitContainer1.Panel1.SuspendLayout();
            this.SplitContainer1.Panel2.SuspendLayout();
            this.SplitContainer1.SuspendLayout();
            this.TableLayoutPanel3.SuspendLayout();
            this.ContextMenuStripSelectBy.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.SplitContainer2.Panel1.SuspendLayout();
            this.SplitContainer2.Panel2.SuspendLayout();
            this.SplitContainer2.SuspendLayout();
            this.SplitContainer5.Panel1.SuspendLayout();
            this.SplitContainer5.Panel2.SuspendLayout();
            this.SplitContainer5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStuPic)).BeginInit();
            this.TableLayoutPanel1.SuspendLayout();
            this.SplitContainer3.Panel1.SuspendLayout();
            this.SplitContainer3.Panel2.SuspendLayout();
            this.SplitContainer3.SuspendLayout();
            this.TableLayoutPanel2.SuspendLayout();
            this.SplitContainer4.Panel1.SuspendLayout();
            this.SplitContainer4.Panel2.SuspendLayout();
            this.SplitContainer4.SuspendLayout();
            this.TableLayoutPanel4.SuspendLayout();
            this.contextMenuStripChangeGradeVal.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileToolStripMenuItem,
            this.SelecToolStripMenuItem,
            this.StudentsToolStripMenuItem,
            this.AssignmentToolStripMenuItem,
            this.EmailToolStripMenuItem,
            this.MiscToolStripMenuItem});
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.Size = new System.Drawing.Size(728, 24);
            this.MenuStrip1.TabIndex = 5;
            this.MenuStrip1.Text = "MenuStrip1";
            // 
            // FileToolStripMenuItem
            // 
            this.FileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LoadProgramDataToolStripMenuItem,
            this.SaveProgramListToolStripMenuItem,
            this.ToolStripSeparator5,
            this.LoadListOfStudentsToolStripMenuItem,
            this.SaveStudentListToolStripMenuItem,
            this.ToolStripSeparator6,
            this.ChooseHomeFolderToolStripMenuItem,
            this.ChoseRemoteFolderToolStripMenuItem,
            this.ToolStripSeparator1,
            this.SaveSettingsToolStripMenuItem,
            this.OpenSettingsToolStripMenuItem,
            this.ToolStripSeparator2,
            this.ExitToolStripMenuItem});
            this.FileToolStripMenuItem.Name = "FileToolStripMenuItem";
            this.FileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.FileToolStripMenuItem.Text = "File";
            // 
            // LoadProgramDataToolStripMenuItem
            // 
            this.LoadProgramDataToolStripMenuItem.Name = "LoadProgramDataToolStripMenuItem";
            this.LoadProgramDataToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.LoadProgramDataToolStripMenuItem.Text = "Import Assignments";
            this.LoadProgramDataToolStripMenuItem.Click += new System.EventHandler(this.LoadProgramDataToolStripMenuItem_Click);
            // 
            // SaveProgramListToolStripMenuItem
            // 
            this.SaveProgramListToolStripMenuItem.Enabled = false;
            this.SaveProgramListToolStripMenuItem.Name = "SaveProgramListToolStripMenuItem";
            this.SaveProgramListToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.SaveProgramListToolStripMenuItem.Text = "Save Program List";
            this.SaveProgramListToolStripMenuItem.Click += new System.EventHandler(this.SaveProgramListToolStripMenuItem_Click);
            // 
            // ToolStripSeparator5
            // 
            this.ToolStripSeparator5.Name = "ToolStripSeparator5";
            this.ToolStripSeparator5.Size = new System.Drawing.Size(190, 6);
            // 
            // LoadListOfStudentsToolStripMenuItem
            // 
            this.LoadListOfStudentsToolStripMenuItem.Name = "LoadListOfStudentsToolStripMenuItem";
            this.LoadListOfStudentsToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.LoadListOfStudentsToolStripMenuItem.Text = "Import Students";
            this.LoadListOfStudentsToolStripMenuItem.Click += new System.EventHandler(this.LoadListOfStudentsToolStripMenuItem_Click);
            // 
            // SaveStudentListToolStripMenuItem
            // 
            this.SaveStudentListToolStripMenuItem.Enabled = false;
            this.SaveStudentListToolStripMenuItem.Name = "SaveStudentListToolStripMenuItem";
            this.SaveStudentListToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.SaveStudentListToolStripMenuItem.Text = "Save Student List";
            this.SaveStudentListToolStripMenuItem.Click += new System.EventHandler(this.SaveStudentListToolStripMenuItem_Click);
            // 
            // ToolStripSeparator6
            // 
            this.ToolStripSeparator6.Name = "ToolStripSeparator6";
            this.ToolStripSeparator6.Size = new System.Drawing.Size(190, 6);
            // 
            // ChooseHomeFolderToolStripMenuItem
            // 
            this.ChooseHomeFolderToolStripMenuItem.Name = "ChooseHomeFolderToolStripMenuItem";
            this.ChooseHomeFolderToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.ChooseHomeFolderToolStripMenuItem.Text = "choose home folder";
            this.ChooseHomeFolderToolStripMenuItem.Click += new System.EventHandler(this.ChooseHomeFolderToolStripMenuItem_Click);
            // 
            // ChoseRemoteFolderToolStripMenuItem
            // 
            this.ChoseRemoteFolderToolStripMenuItem.Name = "ChoseRemoteFolderToolStripMenuItem";
            this.ChoseRemoteFolderToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.ChoseRemoteFolderToolStripMenuItem.Text = "chose Remote Folder";
            this.ChoseRemoteFolderToolStripMenuItem.Click += new System.EventHandler(this.ChoseRemoteFolderToolStripMenuItem_Click);
            // 
            // ToolStripSeparator1
            // 
            this.ToolStripSeparator1.Name = "ToolStripSeparator1";
            this.ToolStripSeparator1.Size = new System.Drawing.Size(190, 6);
            // 
            // SaveSettingsToolStripMenuItem
            // 
            this.SaveSettingsToolStripMenuItem.Name = "SaveSettingsToolStripMenuItem";
            this.SaveSettingsToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.SaveSettingsToolStripMenuItem.Text = "Save Settings";
            this.SaveSettingsToolStripMenuItem.Click += new System.EventHandler(this.SaveSettingsToolStripMenuItem_Click);
            // 
            // OpenSettingsToolStripMenuItem
            // 
            this.OpenSettingsToolStripMenuItem.Name = "OpenSettingsToolStripMenuItem";
            this.OpenSettingsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.OpenSettingsToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.OpenSettingsToolStripMenuItem.Text = "Open Settings";
            this.OpenSettingsToolStripMenuItem.Click += new System.EventHandler(this.OpenSettingsToolStripMenuItem_Click);
            // 
            // ToolStripSeparator2
            // 
            this.ToolStripSeparator2.Name = "ToolStripSeparator2";
            this.ToolStripSeparator2.Size = new System.Drawing.Size(190, 6);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.ExitToolStripMenuItem.Text = "Exit";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // SelecToolStripMenuItem
            // 
            this.SelecToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectAllToolStripMenuItem1,
            this.SelectNoneToolStripMenuItem1,
            this.SelectByLabToolStripMenuItem,
            this.SelectByGradeToolStripMenuItem,
            this.SelectInversToolStripMenuItem,
            this.SelectUngradedToolStripMenuItem});
            this.SelecToolStripMenuItem.Name = "SelecToolStripMenuItem";
            this.SelecToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.SelecToolStripMenuItem.Text = "Select";
            // 
            // SelectAllToolStripMenuItem1
            // 
            this.SelectAllToolStripMenuItem1.Name = "SelectAllToolStripMenuItem1";
            this.SelectAllToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.SelectAllToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.SelectAllToolStripMenuItem1.Text = "Select All";
            this.SelectAllToolStripMenuItem1.Click += new System.EventHandler(this.SelectAllToolStripMenuItem1_Click);
            // 
            // SelectNoneToolStripMenuItem1
            // 
            this.SelectNoneToolStripMenuItem1.Name = "SelectNoneToolStripMenuItem1";
            this.SelectNoneToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.SelectNoneToolStripMenuItem1.Text = "Select None";
            this.SelectNoneToolStripMenuItem1.Click += new System.EventHandler(this.SelectNoneToolStripMenuItem1_Click);
            // 
            // SelectByLabToolStripMenuItem
            // 
            this.SelectByLabToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MondayToolStripMenuItem,
            this.TuesdayToolStripMenuItem,
            this.WednesdayToolStripMenuItem,
            this.ThursdayToolStripMenuItem,
            this.FridayToolStripMenuItem});
            this.SelectByLabToolStripMenuItem.Name = "SelectByLabToolStripMenuItem";
            this.SelectByLabToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.SelectByLabToolStripMenuItem.Text = "Select by Lab";
            // 
            // MondayToolStripMenuItem
            // 
            this.MondayToolStripMenuItem.Name = "MondayToolStripMenuItem";
            this.MondayToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.MondayToolStripMenuItem.Text = "Monday";
            this.MondayToolStripMenuItem.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // TuesdayToolStripMenuItem
            // 
            this.TuesdayToolStripMenuItem.Name = "TuesdayToolStripMenuItem";
            this.TuesdayToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.TuesdayToolStripMenuItem.Text = "Tuesday";
            this.TuesdayToolStripMenuItem.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // WednesdayToolStripMenuItem
            // 
            this.WednesdayToolStripMenuItem.Name = "WednesdayToolStripMenuItem";
            this.WednesdayToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.WednesdayToolStripMenuItem.Text = "Wednesday";
            this.WednesdayToolStripMenuItem.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // ThursdayToolStripMenuItem
            // 
            this.ThursdayToolStripMenuItem.Name = "ThursdayToolStripMenuItem";
            this.ThursdayToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.ThursdayToolStripMenuItem.Text = "Thursday";
            this.ThursdayToolStripMenuItem.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // FridayToolStripMenuItem
            // 
            this.FridayToolStripMenuItem.Name = "FridayToolStripMenuItem";
            this.FridayToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.FridayToolStripMenuItem.Text = "Friday";
            this.FridayToolStripMenuItem.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // SelectByGradeToolStripMenuItem
            // 
            this.SelectByGradeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectGradeToolStripMenuItem1,
            this.txtToolStripGrade});
            this.SelectByGradeToolStripMenuItem.Name = "SelectByGradeToolStripMenuItem";
            this.SelectByGradeToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.SelectByGradeToolStripMenuItem.Text = "Select by grade";
            // 
            // SelectGradeToolStripMenuItem1
            // 
            this.SelectGradeToolStripMenuItem1.Name = "SelectGradeToolStripMenuItem1";
            this.SelectGradeToolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.SelectGradeToolStripMenuItem1.Text = "Select";
            this.SelectGradeToolStripMenuItem1.Click += new System.EventHandler(this.SelectGradeToolStripMenuItem1_Click);
            // 
            // txtToolStripGrade
            // 
            this.txtToolStripGrade.Name = "txtToolStripGrade";
            this.txtToolStripGrade.Size = new System.Drawing.Size(100, 21);
            this.txtToolStripGrade.Text = "1";
            // 
            // SelectInversToolStripMenuItem
            // 
            this.SelectInversToolStripMenuItem.Name = "SelectInversToolStripMenuItem";
            this.SelectInversToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.SelectInversToolStripMenuItem.Text = "Select Inverse";
            this.SelectInversToolStripMenuItem.Click += new System.EventHandler(this.SelectInversToolStripMenuItem_Click);
            // 
            // SelectUngradedToolStripMenuItem
            // 
            this.SelectUngradedToolStripMenuItem.Name = "SelectUngradedToolStripMenuItem";
            this.SelectUngradedToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.SelectUngradedToolStripMenuItem.Text = "Select Ungraded";
            this.SelectUngradedToolStripMenuItem.Click += new System.EventHandler(this.SelectUngradedToolStripMenuItem_Click);
            // 
            // StudentsToolStripMenuItem
            // 
            this.StudentsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddStudentToolStripMenuItem,
            this.EditSelectedStudentToolStripMenuItem,
            this.WithDrawFromClassToolStripMenuItem,
            this.ReenrollSelectedInClassToolStripMenuItem,
            this.DisplayAllGradeToolStripMenuItem,
            this.GetStudentListFromDirectoryToolStripMenuItem});
            this.StudentsToolStripMenuItem.Name = "StudentsToolStripMenuItem";
            this.StudentsToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.StudentsToolStripMenuItem.Text = "Students";
            // 
            // AddStudentToolStripMenuItem
            // 
            this.AddStudentToolStripMenuItem.Name = "AddStudentToolStripMenuItem";
            this.AddStudentToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.AddStudentToolStripMenuItem.Text = "Add Student";
            this.AddStudentToolStripMenuItem.Click += new System.EventHandler(this.AddStudentToolStripMenuItem_Click);
            // 
            // EditSelectedStudentToolStripMenuItem
            // 
            this.EditSelectedStudentToolStripMenuItem.Name = "EditSelectedStudentToolStripMenuItem";
            this.EditSelectedStudentToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.EditSelectedStudentToolStripMenuItem.Text = "Edit Selected Student";
            this.EditSelectedStudentToolStripMenuItem.Click += new System.EventHandler(this.EditSelectedStudentToolStripMenuItem_Click);
            // 
            // WithDrawFromClassToolStripMenuItem
            // 
            this.WithDrawFromClassToolStripMenuItem.Name = "WithDrawFromClassToolStripMenuItem";
            this.WithDrawFromClassToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.WithDrawFromClassToolStripMenuItem.Text = "Withdraw Selected from Class";
            this.WithDrawFromClassToolStripMenuItem.Click += new System.EventHandler(this.WithDrawFromClassToolStripMenuItem_Click);
            // 
            // ReenrollSelectedInClassToolStripMenuItem
            // 
            this.ReenrollSelectedInClassToolStripMenuItem.Name = "ReenrollSelectedInClassToolStripMenuItem";
            this.ReenrollSelectedInClassToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.ReenrollSelectedInClassToolStripMenuItem.Text = "Re-enroll Selected in class";
            this.ReenrollSelectedInClassToolStripMenuItem.Click += new System.EventHandler(this.ReenrollSelectedInClassToolStripMenuItem_Click);
            // 
            // DisplayAllGradeToolStripMenuItem
            // 
            this.DisplayAllGradeToolStripMenuItem.Enabled = false;
            this.DisplayAllGradeToolStripMenuItem.Name = "DisplayAllGradeToolStripMenuItem";
            this.DisplayAllGradeToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.DisplayAllGradeToolStripMenuItem.Text = "Display All Grades for selected";
            // 
            // GetStudentListFromDirectoryToolStripMenuItem
            // 
            this.GetStudentListFromDirectoryToolStripMenuItem.Enabled = false;
            this.GetStudentListFromDirectoryToolStripMenuItem.Name = "GetStudentListFromDirectoryToolStripMenuItem";
            this.GetStudentListFromDirectoryToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.GetStudentListFromDirectoryToolStripMenuItem.Text = "get Student List from directory";
            // 
            // AssignmentToolStripMenuItem
            // 
            this.AssignmentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddAssignmentToolStripMenuItem,
            this.EditSelectedToolStripMenuItem,
            this.ToolStripSeparator4,
            this.DownloadSourcesToolStripMenuItem,
            this.CompileSourcesToolStripMenuItem,
            this.GradeSourcesToolStripMenuItem,
            this.UploadGradesToolStripMenuItem,
            this.ShowtempToolStripMenuItem});
            this.AssignmentToolStripMenuItem.Name = "AssignmentToolStripMenuItem";
            this.AssignmentToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.AssignmentToolStripMenuItem.Text = "Assignment";
            this.AssignmentToolStripMenuItem.Click += new System.EventHandler(this.AssignmentToolStripMenuItem_Click);
            // 
            // AddAssignmentToolStripMenuItem
            // 
            this.AddAssignmentToolStripMenuItem.Name = "AddAssignmentToolStripMenuItem";
            this.AddAssignmentToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.AddAssignmentToolStripMenuItem.Text = "Add Assignment";
            this.AddAssignmentToolStripMenuItem.Click += new System.EventHandler(this.AddAssignmentToolStripMenuItem_Click);
            // 
            // EditSelectedToolStripMenuItem
            // 
            this.EditSelectedToolStripMenuItem.Name = "EditSelectedToolStripMenuItem";
            this.EditSelectedToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.EditSelectedToolStripMenuItem.Text = "Edit Selected";
            this.EditSelectedToolStripMenuItem.Click += new System.EventHandler(this.EditSelectedToolStripMenuItem_Click);
            // 
            // ToolStripSeparator4
            // 
            this.ToolStripSeparator4.Name = "ToolStripSeparator4";
            this.ToolStripSeparator4.Size = new System.Drawing.Size(208, 6);
            // 
            // DownloadSourcesToolStripMenuItem
            // 
            this.DownloadSourcesToolStripMenuItem.Name = "DownloadSourcesToolStripMenuItem";
            this.DownloadSourcesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.DownloadSourcesToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.DownloadSourcesToolStripMenuItem.Text = "Download Sources";
            this.DownloadSourcesToolStripMenuItem.Click += new System.EventHandler(this.DownloadSourcesToolStripMenuItem_Click);
            // 
            // CompileSourcesToolStripMenuItem
            // 
            this.CompileSourcesToolStripMenuItem.Name = "CompileSourcesToolStripMenuItem";
            this.CompileSourcesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D2)));
            this.CompileSourcesToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.CompileSourcesToolStripMenuItem.Text = "Compile Sources";
            this.CompileSourcesToolStripMenuItem.Click += new System.EventHandler(this.CompileSourcesToolStripMenuItem_Click);
            // 
            // GradeSourcesToolStripMenuItem
            // 
            this.GradeSourcesToolStripMenuItem.Name = "GradeSourcesToolStripMenuItem";
            this.GradeSourcesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D3)));
            this.GradeSourcesToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.GradeSourcesToolStripMenuItem.Text = "Grade Sources";
            this.GradeSourcesToolStripMenuItem.Click += new System.EventHandler(this.GradeSourcesToolStripMenuItem_Click);
            // 
            // UploadGradesToolStripMenuItem
            // 
            this.UploadGradesToolStripMenuItem.Name = "UploadGradesToolStripMenuItem";
            this.UploadGradesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D4)));
            this.UploadGradesToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.UploadGradesToolStripMenuItem.Text = "Upload Grades";
            this.UploadGradesToolStripMenuItem.Click += new System.EventHandler(this.UploadGradesToolStripMenuItem_Click);
            // 
            // ShowtempToolStripMenuItem
            // 
            this.ShowtempToolStripMenuItem.Name = "ShowtempToolStripMenuItem";
            this.ShowtempToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.ShowtempToolStripMenuItem.Text = "show(temp)";
            // 
            // EmailToolStripMenuItem
            // 
            this.EmailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EmailAssignmentGradeToCheckedToolStripMenuItem,
            this.ToolStripSeparator3,
            this.toolStriptxtEmailFrom,
            this.ToolStriptxtEmailPassword});
            this.EmailToolStripMenuItem.Name = "EmailToolStripMenuItem";
            this.EmailToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.EmailToolStripMenuItem.Text = "Email";
            // 
            // EmailAssignmentGradeToCheckedToolStripMenuItem
            // 
            this.EmailAssignmentGradeToCheckedToolStripMenuItem.Name = "EmailAssignmentGradeToCheckedToolStripMenuItem";
            this.EmailAssignmentGradeToCheckedToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.EmailAssignmentGradeToCheckedToolStripMenuItem.Text = "Email Assignment Grade to checked";
            this.EmailAssignmentGradeToCheckedToolStripMenuItem.Click += new System.EventHandler(this.EmailAssignmentGradeToCheckedToolStripMenuItem_Click);
            // 
            // ToolStripSeparator3
            // 
            this.ToolStripSeparator3.Name = "ToolStripSeparator3";
            this.ToolStripSeparator3.Size = new System.Drawing.Size(251, 6);
            // 
            // toolStriptxtEmailFrom
            // 
            this.toolStriptxtEmailFrom.AutoSize = false;
            this.toolStriptxtEmailFrom.Name = "toolStriptxtEmailFrom";
            this.toolStriptxtEmailFrom.Size = new System.Drawing.Size(180, 21);
            this.toolStriptxtEmailFrom.Text = "ece161Grader@gmail.com";
            // 
            // ToolStriptxtEmailPassword
            // 
            this.ToolStriptxtEmailPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ToolStriptxtEmailPassword.ForeColor = System.Drawing.SystemColors.Window;
            this.ToolStriptxtEmailPassword.Name = "ToolStriptxtEmailPassword";
            this.ToolStriptxtEmailPassword.Size = new System.Drawing.Size(180, 21);
            this.ToolStriptxtEmailPassword.Text = "pianpian";
            // 
            // MiscToolStripMenuItem
            // 
            this.MiscToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CopyGradesToClipboardToolStripMenuItem,
            this.GenerateComparisonDirToolStripMenuItem,
            this.GenerateStudentsFromRemoteDirToolStripMenuItem,
            this.EditSettingsToolStripMenuItem,
            this.testToolStripMenuItem,
            this.launchCmdPromptToolStripMenuItem});
            this.MiscToolStripMenuItem.Name = "MiscToolStripMenuItem";
            this.MiscToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.MiscToolStripMenuItem.Text = "Misc";
            // 
            // CopyGradesToClipboardToolStripMenuItem
            // 
            this.CopyGradesToClipboardToolStripMenuItem.Name = "CopyGradesToClipboardToolStripMenuItem";
            this.CopyGradesToClipboardToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.CopyGradesToClipboardToolStripMenuItem.Text = "copy grades to clipboard";
            this.CopyGradesToClipboardToolStripMenuItem.Click += new System.EventHandler(this.CopyGradesToClipboardToolStripMenuItem_Click);
            // 
            // GenerateComparisonDirToolStripMenuItem
            // 
            this.GenerateComparisonDirToolStripMenuItem.Name = "GenerateComparisonDirToolStripMenuItem";
            this.GenerateComparisonDirToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.GenerateComparisonDirToolStripMenuItem.Text = "Generate Comparison Dir";
            // 
            // GenerateStudentsFromRemoteDirToolStripMenuItem
            // 
            this.GenerateStudentsFromRemoteDirToolStripMenuItem.Name = "GenerateStudentsFromRemoteDirToolStripMenuItem";
            this.GenerateStudentsFromRemoteDirToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.GenerateStudentsFromRemoteDirToolStripMenuItem.Text = "Generate Students from remote Dir";
            // 
            // EditSettingsToolStripMenuItem
            // 
            this.EditSettingsToolStripMenuItem.Name = "EditSettingsToolStripMenuItem";
            this.EditSettingsToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.EditSettingsToolStripMenuItem.Text = "Edit Settings";
            this.EditSettingsToolStripMenuItem.Click += new System.EventHandler(this.EditSettingsToolStripMenuItem_Click);
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.testToolStripMenuItem.Text = "test";
            this.testToolStripMenuItem.Click += new System.EventHandler(this.testToolStripMenuItem_Click);
            // 
            // launchCmdPromptToolStripMenuItem
            // 
            this.launchCmdPromptToolStripMenuItem.Name = "launchCmdPromptToolStripMenuItem";
            this.launchCmdPromptToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.launchCmdPromptToolStripMenuItem.Text = "launch cmdPrompt";
            this.launchCmdPromptToolStripMenuItem.Click += new System.EventHandler(this.launchCmdPromptToolStripMenuItem_Click);
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblLocalDir,
            this.lblRemoteDir,
            this.tslblCurrentProg,
            this.tslblCurrentStudent});
            this.StatusStrip1.Location = new System.Drawing.Point(0, 440);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(728, 22);
            this.StatusStrip1.TabIndex = 8;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // lblLocalDir
            // 
            this.lblLocalDir.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblLocalDir.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblLocalDir.Name = "lblLocalDir";
            this.lblLocalDir.Size = new System.Drawing.Size(48, 17);
            this.lblLocalDir.Text = "local Dir";
            this.lblLocalDir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblRemoteDir
            // 
            this.lblRemoteDir.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblRemoteDir.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblRemoteDir.Name = "lblRemoteDir";
            this.lblRemoteDir.Size = new System.Drawing.Size(64, 17);
            this.lblRemoteDir.Text = "Remote Dir";
            // 
            // tslblCurrentProg
            // 
            this.tslblCurrentProg.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tslblCurrentProg.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.tslblCurrentProg.Name = "tslblCurrentProg";
            this.tslblCurrentProg.Size = new System.Drawing.Size(70, 17);
            this.tslblCurrentProg.Text = "CurrentProg";
            // 
            // tslblCurrentStudent
            // 
            this.tslblCurrentStudent.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tslblCurrentStudent.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.tslblCurrentStudent.Name = "tslblCurrentStudent";
            this.tslblCurrentStudent.Size = new System.Drawing.Size(89, 17);
            this.tslblCurrentStudent.Text = "Current Student";
            // 
            // SplitContainer1
            // 
            this.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SplitContainer1.Location = new System.Drawing.Point(0, 24);
            this.SplitContainer1.Name = "SplitContainer1";
            // 
            // SplitContainer1.Panel1
            // 
            this.SplitContainer1.Panel1.Controls.Add(this.TableLayoutPanel3);
            this.SplitContainer1.Panel1MinSize = 121;
            // 
            // SplitContainer1.Panel2
            // 
            this.SplitContainer1.Panel2.Controls.Add(this.SplitContainer2);
            this.SplitContainer1.Size = new System.Drawing.Size(728, 416);
            this.SplitContainer1.SplitterDistance = 133;
            this.SplitContainer1.TabIndex = 9;
            // 
            // TableLayoutPanel3
            // 
            this.TableLayoutPanel3.ColumnCount = 1;
            this.TableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel3.Controls.Add(this.cmbProglist, 0, 0);
            this.TableLayoutPanel3.Controls.Add(this.chkListStuList, 0, 1);
            this.TableLayoutPanel3.Controls.Add(this.chkShowWithdrawn, 0, 2);
            this.TableLayoutPanel3.Controls.Add(this.chkUseFlags, 0, 3);
            this.TableLayoutPanel3.Controls.Add(this.chkAutoAdvance, 0, 4);
            this.TableLayoutPanel3.Controls.Add(this.chkAutoDelete, 0, 5);
            this.TableLayoutPanel3.Controls.Add(this.GroupBox1, 0, 8);
            this.TableLayoutPanel3.Controls.Add(this.GroupBox2, 0, 7);
            this.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.TableLayoutPanel3.Name = "TableLayoutPanel3";
            this.TableLayoutPanel3.RowCount = 9;
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.TableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.TableLayoutPanel3.Size = new System.Drawing.Size(129, 412);
            this.TableLayoutPanel3.TabIndex = 0;
            // 
            // cmbProglist
            // 
            this.cmbProglist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbProglist.FormattingEnabled = true;
            this.cmbProglist.Location = new System.Drawing.Point(3, 3);
            this.cmbProglist.Name = "cmbProglist";
            this.cmbProglist.Size = new System.Drawing.Size(123, 21);
            this.cmbProglist.TabIndex = 3;
            this.cmbProglist.SelectedIndexChanged += new System.EventHandler(this.cmbProglist_SelectedIndexChanged);
            // 
            // chkListStuList
            // 
            this.chkListStuList.ContextMenuStrip = this.ContextMenuStripSelectBy;
            this.chkListStuList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chkListStuList.FormattingEnabled = true;
            this.chkListStuList.IntegralHeight = false;
            this.chkListStuList.Location = new System.Drawing.Point(3, 30);
            this.chkListStuList.MinimumSize = new System.Drawing.Size(4, 40);
            this.chkListStuList.Name = "chkListStuList";
            this.chkListStuList.Size = new System.Drawing.Size(123, 154);
            this.chkListStuList.TabIndex = 0;
            this.chkListStuList.SelectedIndexChanged += new System.EventHandler(this.chkListStuList_SelectedIndexChanged);
            // 
            // ContextMenuStripSelectBy
            // 
            this.ContextMenuStripSelectBy.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectAllToolStripMenuItem,
            this.SelectNoneToolStripMenuItem,
            this.SelectInverseToolStripMenuItem,
            this.selectByGradeToolStripMenuItem1,
            this.SelectLab1ToolStripMenuItem,
            this.SelectGradedToolStripMenuItem,
            this.rerunSelectedStudentONLYToolStripMenuItem,
            this.debugStudentToolStripMenuItem});
            this.ContextMenuStripSelectBy.Name = "ContextMenuStrip1";
            this.ContextMenuStripSelectBy.Size = new System.Drawing.Size(224, 202);
            // 
            // SelectAllToolStripMenuItem
            // 
            this.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem";
            this.SelectAllToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.SelectAllToolStripMenuItem.Text = "Select all";
            this.SelectAllToolStripMenuItem.Click += new System.EventHandler(this.SelectAllToolStripMenuItem1_Click);
            // 
            // SelectNoneToolStripMenuItem
            // 
            this.SelectNoneToolStripMenuItem.Name = "SelectNoneToolStripMenuItem";
            this.SelectNoneToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.SelectNoneToolStripMenuItem.Text = "Select none";
            this.SelectNoneToolStripMenuItem.Click += new System.EventHandler(this.SelectNoneToolStripMenuItem1_Click);
            // 
            // SelectInverseToolStripMenuItem
            // 
            this.SelectInverseToolStripMenuItem.Name = "SelectInverseToolStripMenuItem";
            this.SelectInverseToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.SelectInverseToolStripMenuItem.Text = "Select Inverse";
            this.SelectInverseToolStripMenuItem.Click += new System.EventHandler(this.SelectInversToolStripMenuItem_Click);
            // 
            // selectByGradeToolStripMenuItem1
            // 
            this.selectByGradeToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectToolStripMenuItem,
            this.toolStripTextBox1});
            this.selectByGradeToolStripMenuItem1.Name = "selectByGradeToolStripMenuItem1";
            this.selectByGradeToolStripMenuItem1.Size = new System.Drawing.Size(223, 22);
            this.selectByGradeToolStripMenuItem1.Text = "Select by Grade";
            // 
            // selectToolStripMenuItem
            // 
            this.selectToolStripMenuItem.Name = "selectToolStripMenuItem";
            this.selectToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.selectToolStripMenuItem.Text = "Select";
            this.selectToolStripMenuItem.Click += new System.EventHandler(this.selectToolStripMenuItem_Click);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 21);
            // 
            // SelectLab1ToolStripMenuItem
            // 
            this.SelectLab1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MondayToolStripMenuItem1,
            this.TuesdayToolStripMenuItem1,
            this.WednesdayToolStripMenuItem1,
            this.ThursdayToolStripMenuItem1,
            this.FridayToolStripMenuItem1});
            this.SelectLab1ToolStripMenuItem.Name = "SelectLab1ToolStripMenuItem";
            this.SelectLab1ToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.SelectLab1ToolStripMenuItem.Text = "Select by Lab";
            // 
            // MondayToolStripMenuItem1
            // 
            this.MondayToolStripMenuItem1.Name = "MondayToolStripMenuItem1";
            this.MondayToolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
            this.MondayToolStripMenuItem1.Text = "Monday";
            this.MondayToolStripMenuItem1.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // TuesdayToolStripMenuItem1
            // 
            this.TuesdayToolStripMenuItem1.Name = "TuesdayToolStripMenuItem1";
            this.TuesdayToolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
            this.TuesdayToolStripMenuItem1.Text = "Tuesday";
            this.TuesdayToolStripMenuItem1.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // WednesdayToolStripMenuItem1
            // 
            this.WednesdayToolStripMenuItem1.Name = "WednesdayToolStripMenuItem1";
            this.WednesdayToolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
            this.WednesdayToolStripMenuItem1.Text = "Wednesday";
            this.WednesdayToolStripMenuItem1.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // ThursdayToolStripMenuItem1
            // 
            this.ThursdayToolStripMenuItem1.Name = "ThursdayToolStripMenuItem1";
            this.ThursdayToolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
            this.ThursdayToolStripMenuItem1.Text = "Thursday";
            this.ThursdayToolStripMenuItem1.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // FridayToolStripMenuItem1
            // 
            this.FridayToolStripMenuItem1.Name = "FridayToolStripMenuItem1";
            this.FridayToolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
            this.FridayToolStripMenuItem1.Text = "Friday";
            this.FridayToolStripMenuItem1.Click += new System.EventHandler(this.SelectByLabToolStripMenuItem_Click);
            // 
            // SelectGradedToolStripMenuItem
            // 
            this.SelectGradedToolStripMenuItem.Name = "SelectGradedToolStripMenuItem";
            this.SelectGradedToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.SelectGradedToolStripMenuItem.Text = "Select Ungraded";
            this.SelectGradedToolStripMenuItem.Click += new System.EventHandler(this.SelectUngradedToolStripMenuItem_Click);
            // 
            // rerunSelectedStudentONLYToolStripMenuItem
            // 
            this.rerunSelectedStudentONLYToolStripMenuItem.Name = "rerunSelectedStudentONLYToolStripMenuItem";
            this.rerunSelectedStudentONLYToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.rerunSelectedStudentONLYToolStripMenuItem.Text = "rerun selected student ONLY";
            this.rerunSelectedStudentONLYToolStripMenuItem.Click += new System.EventHandler(this.rerunSelectedStudentONLYToolStripMenuItem_Click);
            // 
            // chkShowWithdrawn
            // 
            this.chkShowWithdrawn.AutoSize = true;
            this.chkShowWithdrawn.Location = new System.Drawing.Point(3, 190);
            this.chkShowWithdrawn.Name = "chkShowWithdrawn";
            this.chkShowWithdrawn.Size = new System.Drawing.Size(107, 17);
            this.chkShowWithdrawn.TabIndex = 4;
            this.chkShowWithdrawn.Text = "Show Withdrawn";
            this.chkShowWithdrawn.UseVisualStyleBackColor = true;
            this.chkShowWithdrawn.CheckedChanged += new System.EventHandler(this.chkShowWithdrawn_CheckedChanged);
            // 
            // chkUseFlags
            // 
            this.chkUseFlags.AutoSize = true;
            this.chkUseFlags.Location = new System.Drawing.Point(3, 213);
            this.chkUseFlags.Name = "chkUseFlags";
            this.chkUseFlags.Size = new System.Drawing.Size(111, 17);
            this.chkUseFlags.TabIndex = 7;
            this.chkUseFlags.Text = "Use Custom Flags";
            this.chkUseFlags.UseVisualStyleBackColor = true;
            // 
            // chkAutoAdvance
            // 
            this.chkAutoAdvance.AutoSize = true;
            this.chkAutoAdvance.Location = new System.Drawing.Point(3, 236);
            this.chkAutoAdvance.Name = "chkAutoAdvance";
            this.chkAutoAdvance.Size = new System.Drawing.Size(90, 17);
            this.chkAutoAdvance.TabIndex = 8;
            this.chkAutoAdvance.Text = "autoAdvance";
            this.chkAutoAdvance.UseVisualStyleBackColor = true;
            // 
            // chkAutoDelete
            // 
            this.chkAutoDelete.AutoSize = true;
            this.chkAutoDelete.Location = new System.Drawing.Point(3, 259);
            this.chkAutoDelete.Name = "chkAutoDelete";
            this.chkAutoDelete.Size = new System.Drawing.Size(117, 16);
            this.chkAutoDelete.TabIndex = 9;
            this.chkAutoDelete.Text = "autoDelete obj/exe";
            this.chkAutoDelete.UseVisualStyleBackColor = true;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.txtCustFlags);
            this.GroupBox1.Location = new System.Drawing.Point(3, 365);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(123, 43);
            this.GroupBox1.TabIndex = 5;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Custom Flags";
            // 
            // txtCustFlags
            // 
            this.txtCustFlags.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCustFlags.Location = new System.Drawing.Point(3, 16);
            this.txtCustFlags.Name = "txtCustFlags";
            this.txtCustFlags.Size = new System.Drawing.Size(117, 20);
            this.txtCustFlags.TabIndex = 0;
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.txtProgTimeout);
            this.GroupBox2.Location = new System.Drawing.Point(3, 319);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(123, 38);
            this.GroupBox2.TabIndex = 6;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Seconds to wait";
            // 
            // txtProgTimeout
            // 
            this.txtProgTimeout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtProgTimeout.Location = new System.Drawing.Point(3, 16);
            this.txtProgTimeout.Name = "txtProgTimeout";
            this.txtProgTimeout.Size = new System.Drawing.Size(117, 20);
            this.txtProgTimeout.TabIndex = 0;
            this.txtProgTimeout.Text = "2";
            // 
            // SplitContainer2
            // 
            this.SplitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SplitContainer2.Location = new System.Drawing.Point(0, 0);
            this.SplitContainer2.Name = "SplitContainer2";
            this.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // SplitContainer2.Panel1
            // 
            this.SplitContainer2.Panel1.Controls.Add(this.SplitContainer5);
            // 
            // SplitContainer2.Panel2
            // 
            this.SplitContainer2.Panel2.Controls.Add(this.TableLayoutPanel1);
            this.SplitContainer2.Size = new System.Drawing.Size(591, 416);
            this.SplitContainer2.SplitterDistance = 134;
            this.SplitContainer2.TabIndex = 0;
            // 
            // SplitContainer5
            // 
            this.SplitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SplitContainer5.Location = new System.Drawing.Point(0, 0);
            this.SplitContainer5.Name = "SplitContainer5";
            // 
            // SplitContainer5.Panel1
            // 
            this.SplitContainer5.Panel1.Controls.Add(this.txtGrade);
            // 
            // SplitContainer5.Panel2
            // 
            this.SplitContainer5.Panel2.Controls.Add(this.picStuPic);
            this.SplitContainer5.Size = new System.Drawing.Size(587, 130);
            this.SplitContainer5.SplitterDistance = 494;
            this.SplitContainer5.TabIndex = 3;
            // 
            // txtGrade
            // 
            this.txtGrade.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGrade.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGrade.Location = new System.Drawing.Point(0, 0);
            this.txtGrade.Multiline = true;
            this.txtGrade.Name = "txtGrade";
            this.txtGrade.Size = new System.Drawing.Size(494, 130);
            this.txtGrade.TabIndex = 3;
            // 
            // picStuPic
            // 
            this.picStuPic.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picStuPic.Location = new System.Drawing.Point(0, 0);
            this.picStuPic.Name = "picStuPic";
            this.picStuPic.Size = new System.Drawing.Size(89, 130);
            this.picStuPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picStuPic.TabIndex = 0;
            this.picStuPic.TabStop = false;
            // 
            // TableLayoutPanel1
            // 
            this.TableLayoutPanel1.ColumnCount = 1;
            this.TableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel1.Controls.Add(this.SplitContainer3, 0, 0);
            this.TableLayoutPanel1.Controls.Add(this.SplitContainer4, 0, 1);
            this.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.TableLayoutPanel1.Name = "TableLayoutPanel1";
            this.TableLayoutPanel1.RowCount = 2;
            this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.TableLayoutPanel1.Size = new System.Drawing.Size(587, 274);
            this.TableLayoutPanel1.TabIndex = 0;
            // 
            // SplitContainer3
            // 
            this.SplitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.SplitContainer3.Location = new System.Drawing.Point(3, 3);
            this.SplitContainer3.Name = "SplitContainer3";
            // 
            // SplitContainer3.Panel1
            // 
            this.SplitContainer3.Panel1.Controls.Add(this.TableLayoutPanel2);
            // 
            // SplitContainer3.Panel2
            // 
            this.SplitContainer3.Panel2.Controls.Add(this.txtMain);
            this.SplitContainer3.Size = new System.Drawing.Size(581, 207);
            this.SplitContainer3.SplitterDistance = 25;
            this.SplitContainer3.TabIndex = 0;
            // 
            // TableLayoutPanel2
            // 
            this.TableLayoutPanel2.ColumnCount = 1;
            this.TableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TableLayoutPanel2.Controls.Add(this.gotoOutput, 0, 3);
            this.TableLayoutPanel2.Controls.Add(this.gotoCompiler, 0, 2);
            this.TableLayoutPanel2.Controls.Add(this.gotoCode, 0, 1);
            this.TableLayoutPanel2.Controls.Add(this.gotoComment, 0, 0);
            this.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.TableLayoutPanel2.Name = "TableLayoutPanel2";
            this.TableLayoutPanel2.RowCount = 4;
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.TableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.TableLayoutPanel2.Size = new System.Drawing.Size(21, 203);
            this.TableLayoutPanel2.TabIndex = 0;
            // 
            // gotoOutput
            // 
            this.gotoOutput.Appearance = System.Windows.Forms.Appearance.Button;
            this.gotoOutput.AutoSize = true;
            this.gotoOutput.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gotoOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gotoOutput.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gotoOutput.Location = new System.Drawing.Point(3, 153);
            this.gotoOutput.Name = "gotoOutput";
            this.gotoOutput.Size = new System.Drawing.Size(15, 47);
            this.gotoOutput.TabIndex = 3;
            this.gotoOutput.Text = "Output";
            this.gotoOutput.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.gotoOutput.UseVisualStyleBackColor = true;
            // 
            // gotoCompiler
            // 
            this.gotoCompiler.Appearance = System.Windows.Forms.Appearance.Button;
            this.gotoCompiler.AutoSize = true;
            this.gotoCompiler.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gotoCompiler.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gotoCompiler.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gotoCompiler.Location = new System.Drawing.Point(3, 103);
            this.gotoCompiler.Name = "gotoCompiler";
            this.gotoCompiler.Size = new System.Drawing.Size(15, 44);
            this.gotoCompiler.TabIndex = 2;
            this.gotoCompiler.Tag = "";
            this.gotoCompiler.Text = "Compiler";
            this.gotoCompiler.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.gotoCompiler.UseVisualStyleBackColor = true;
            // 
            // gotoCode
            // 
            this.gotoCode.Appearance = System.Windows.Forms.Appearance.Button;
            this.gotoCode.AutoSize = true;
            this.gotoCode.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gotoCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gotoCode.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gotoCode.Location = new System.Drawing.Point(3, 53);
            this.gotoCode.Name = "gotoCode";
            this.gotoCode.Size = new System.Drawing.Size(15, 44);
            this.gotoCode.TabIndex = 1;
            this.gotoCode.Text = "Code";
            this.gotoCode.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.gotoCode.UseVisualStyleBackColor = true;
            // 
            // gotoComment
            // 
            this.gotoComment.Appearance = System.Windows.Forms.Appearance.Button;
            this.gotoComment.AutoSize = true;
            this.gotoComment.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gotoComment.Checked = true;
            this.gotoComment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gotoComment.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.gotoComment.Location = new System.Drawing.Point(3, 3);
            this.gotoComment.Name = "gotoComment";
            this.gotoComment.Size = new System.Drawing.Size(15, 44);
            this.gotoComment.TabIndex = 0;
            this.gotoComment.TabStop = true;
            this.gotoComment.Text = "Comment";
            this.gotoComment.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.gotoComment.UseVisualStyleBackColor = true;
            this.gotoComment.Click += new System.EventHandler(this.goto_Click);
            // 
            // txtMain
            // 
            this.txtMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMain.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMain.Location = new System.Drawing.Point(0, 0);
            this.txtMain.MaxLength = 65535;
            this.txtMain.Multiline = true;
            this.txtMain.Name = "txtMain";
            this.txtMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMain.Size = new System.Drawing.Size(548, 203);
            this.txtMain.TabIndex = 1;
            // 
            // SplitContainer4
            // 
            this.SplitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SplitContainer4.Location = new System.Drawing.Point(3, 216);
            this.SplitContainer4.Name = "SplitContainer4";
            // 
            // SplitContainer4.Panel1
            // 
            this.SplitContainer4.Panel1.Controls.Add(this.TableLayoutPanel4);
            // 
            // SplitContainer4.Panel2
            // 
            this.SplitContainer4.Panel2.Controls.Add(this.lblLate);
            this.SplitContainer4.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.SplitContainer4_Panel2_Paint);
            this.SplitContainer4.Size = new System.Drawing.Size(581, 55);
            this.SplitContainer4.SplitterDistance = 477;
            this.SplitContainer4.TabIndex = 1;
            // 
            // TableLayoutPanel4
            // 
            this.TableLayoutPanel4.ColumnCount = 11;
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.TableLayoutPanel4.Controls.Add(this.grd25, 9, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd35, 8, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd45, 7, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd55, 6, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd65, 5, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd75, 4, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd85, 3, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd95, 2, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd0, 1, 1);
            this.TableLayoutPanel4.Controls.Add(this.cmdNext, 0, 1);
            this.TableLayoutPanel4.Controls.Add(this.grd10, 10, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd20, 9, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd30, 8, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd40, 7, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd50, 6, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd60, 5, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd70, 4, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd80, 3, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd90, 2, 0);
            this.TableLayoutPanel4.Controls.Add(this.grd100, 1, 0);
            this.TableLayoutPanel4.Controls.Add(this.cmdPrev, 0, 0);
            this.TableLayoutPanel4.Controls.Add(this.grdCustom, 10, 1);
            this.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.TableLayoutPanel4.Name = "TableLayoutPanel4";
            this.TableLayoutPanel4.RowCount = 2;
            this.TableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.TableLayoutPanel4.Size = new System.Drawing.Size(473, 51);
            this.TableLayoutPanel4.TabIndex = 1;
            // 
            // grd25
            // 
            this.grd25.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd25.Location = new System.Drawing.Point(381, 28);
            this.grd25.Name = "grd25";
            this.grd25.Size = new System.Drawing.Size(36, 20);
            this.grd25.TabIndex = 20;
            this.grd25.Text = "25";
            this.grd25.UseVisualStyleBackColor = true;
            this.grd25.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // contextMenuStripChangeGradeVal
            // 
            this.contextMenuStripChangeGradeVal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBoxNewGrade});
            this.contextMenuStripChangeGradeVal.Name = "contextMenuStripChangeGradeVal";
            this.contextMenuStripChangeGradeVal.Size = new System.Drawing.Size(161, 27);
            this.contextMenuStripChangeGradeVal.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStripChangeGradeVal_Opening);
            this.contextMenuStripChangeGradeVal.Closing += new System.Windows.Forms.ToolStripDropDownClosingEventHandler(this.contextMenuStripChangeGradeVal_Closing);
            // 
            // toolStripTextBoxNewGrade
            // 
            this.toolStripTextBoxNewGrade.MaxLength = 4;
            this.toolStripTextBoxNewGrade.Name = "toolStripTextBoxNewGrade";
            this.toolStripTextBoxNewGrade.Size = new System.Drawing.Size(100, 21);
            this.toolStripTextBoxNewGrade.KeyDown += new System.Windows.Forms.KeyEventHandler(this.toolStripTextBoxNewGrade_KeyDown);
            // 
            // grd35
            // 
            this.grd35.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd35.Location = new System.Drawing.Point(339, 28);
            this.grd35.Name = "grd35";
            this.grd35.Size = new System.Drawing.Size(36, 20);
            this.grd35.TabIndex = 19;
            this.grd35.Text = "35";
            this.grd35.UseVisualStyleBackColor = true;
            this.grd35.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd45
            // 
            this.grd45.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd45.Location = new System.Drawing.Point(297, 28);
            this.grd45.Name = "grd45";
            this.grd45.Size = new System.Drawing.Size(36, 20);
            this.grd45.TabIndex = 18;
            this.grd45.Text = "45";
            this.grd45.UseVisualStyleBackColor = true;
            this.grd45.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd55
            // 
            this.grd55.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd55.Location = new System.Drawing.Point(255, 28);
            this.grd55.Name = "grd55";
            this.grd55.Size = new System.Drawing.Size(36, 20);
            this.grd55.TabIndex = 17;
            this.grd55.Text = "55";
            this.grd55.UseVisualStyleBackColor = true;
            this.grd55.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd65
            // 
            this.grd65.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd65.Location = new System.Drawing.Point(213, 28);
            this.grd65.Name = "grd65";
            this.grd65.Size = new System.Drawing.Size(36, 20);
            this.grd65.TabIndex = 16;
            this.grd65.Text = "65";
            this.grd65.UseVisualStyleBackColor = true;
            this.grd65.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd75
            // 
            this.grd75.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd75.Location = new System.Drawing.Point(171, 28);
            this.grd75.Name = "grd75";
            this.grd75.Size = new System.Drawing.Size(36, 20);
            this.grd75.TabIndex = 15;
            this.grd75.Text = "75";
            this.grd75.UseVisualStyleBackColor = true;
            this.grd75.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd85
            // 
            this.grd85.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd85.Location = new System.Drawing.Point(129, 28);
            this.grd85.Name = "grd85";
            this.grd85.Size = new System.Drawing.Size(36, 20);
            this.grd85.TabIndex = 14;
            this.grd85.Text = "85";
            this.grd85.UseVisualStyleBackColor = true;
            this.grd85.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd95
            // 
            this.grd95.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd95.Location = new System.Drawing.Point(87, 28);
            this.grd95.Name = "grd95";
            this.grd95.Size = new System.Drawing.Size(36, 20);
            this.grd95.TabIndex = 13;
            this.grd95.Text = "95";
            this.grd95.UseVisualStyleBackColor = true;
            this.grd95.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd0
            // 
            this.grd0.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd0.Location = new System.Drawing.Point(45, 28);
            this.grd0.Name = "grd0";
            this.grd0.Size = new System.Drawing.Size(36, 20);
            this.grd0.TabIndex = 12;
            this.grd0.Text = "0";
            this.grd0.UseVisualStyleBackColor = true;
            this.grd0.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // cmdNext
            // 
            this.cmdNext.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmdNext.Location = new System.Drawing.Point(3, 28);
            this.cmdNext.Name = "cmdNext";
            this.cmdNext.Size = new System.Drawing.Size(36, 20);
            this.cmdNext.TabIndex = 11;
            this.cmdNext.Text = "Next";
            this.cmdNext.UseVisualStyleBackColor = true;
            this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
            // 
            // grd10
            // 
            this.grd10.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd10.Location = new System.Drawing.Point(423, 3);
            this.grd10.Name = "grd10";
            this.grd10.Size = new System.Drawing.Size(47, 19);
            this.grd10.TabIndex = 10;
            this.grd10.Text = "10";
            this.grd10.UseVisualStyleBackColor = true;
            this.grd10.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd20
            // 
            this.grd20.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd20.Location = new System.Drawing.Point(381, 3);
            this.grd20.Name = "grd20";
            this.grd20.Size = new System.Drawing.Size(36, 19);
            this.grd20.TabIndex = 9;
            this.grd20.Text = "20";
            this.grd20.UseVisualStyleBackColor = true;
            this.grd20.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd30
            // 
            this.grd30.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd30.Location = new System.Drawing.Point(339, 3);
            this.grd30.Name = "grd30";
            this.grd30.Size = new System.Drawing.Size(36, 19);
            this.grd30.TabIndex = 8;
            this.grd30.Text = "30";
            this.grd30.UseVisualStyleBackColor = true;
            this.grd30.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd40
            // 
            this.grd40.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd40.Location = new System.Drawing.Point(297, 3);
            this.grd40.Name = "grd40";
            this.grd40.Size = new System.Drawing.Size(36, 19);
            this.grd40.TabIndex = 7;
            this.grd40.Text = "40";
            this.grd40.UseVisualStyleBackColor = true;
            this.grd40.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd50
            // 
            this.grd50.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd50.Location = new System.Drawing.Point(255, 3);
            this.grd50.Name = "grd50";
            this.grd50.Size = new System.Drawing.Size(36, 19);
            this.grd50.TabIndex = 6;
            this.grd50.Text = "50";
            this.grd50.UseVisualStyleBackColor = true;
            this.grd50.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd60
            // 
            this.grd60.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd60.Location = new System.Drawing.Point(213, 3);
            this.grd60.Name = "grd60";
            this.grd60.Size = new System.Drawing.Size(36, 19);
            this.grd60.TabIndex = 5;
            this.grd60.Text = "60";
            this.grd60.UseVisualStyleBackColor = true;
            this.grd60.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd70
            // 
            this.grd70.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd70.Location = new System.Drawing.Point(171, 3);
            this.grd70.Name = "grd70";
            this.grd70.Size = new System.Drawing.Size(36, 19);
            this.grd70.TabIndex = 4;
            this.grd70.Text = "70";
            this.grd70.UseVisualStyleBackColor = true;
            this.grd70.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd80
            // 
            this.grd80.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd80.Location = new System.Drawing.Point(129, 3);
            this.grd80.Name = "grd80";
            this.grd80.Size = new System.Drawing.Size(36, 19);
            this.grd80.TabIndex = 3;
            this.grd80.Text = "80";
            this.grd80.UseVisualStyleBackColor = true;
            this.grd80.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd90
            // 
            this.grd90.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd90.Location = new System.Drawing.Point(87, 3);
            this.grd90.Name = "grd90";
            this.grd90.Size = new System.Drawing.Size(36, 19);
            this.grd90.TabIndex = 2;
            this.grd90.Text = "90";
            this.grd90.UseVisualStyleBackColor = true;
            this.grd90.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // grd100
            // 
            this.grd100.ContextMenuStrip = this.contextMenuStripChangeGradeVal;
            this.grd100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grd100.Location = new System.Drawing.Point(45, 3);
            this.grd100.Name = "grd100";
            this.grd100.Size = new System.Drawing.Size(36, 19);
            this.grd100.TabIndex = 1;
            this.grd100.Text = "100";
            this.grd100.UseVisualStyleBackColor = true;
            this.grd100.Click += new System.EventHandler(this.cmdGrd_Click);
            // 
            // cmdPrev
            // 
            this.cmdPrev.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmdPrev.Location = new System.Drawing.Point(3, 3);
            this.cmdPrev.Name = "cmdPrev";
            this.cmdPrev.Size = new System.Drawing.Size(36, 19);
            this.cmdPrev.TabIndex = 0;
            this.cmdPrev.Text = "Prev";
            this.cmdPrev.UseVisualStyleBackColor = true;
            this.cmdPrev.Click += new System.EventHandler(this.cmdPrev_Click);
            // 
            // grdCustom
            // 
            this.grdCustom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdCustom.Location = new System.Drawing.Point(423, 28);
            this.grdCustom.Multiline = true;
            this.grdCustom.Name = "grdCustom";
            this.grdCustom.Size = new System.Drawing.Size(47, 20);
            this.grdCustom.TabIndex = 21;
            this.grdCustom.Text = "5";
            this.grdCustom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.grdCustom.DoubleClick += new System.EventHandler(this.cmdGrd_Click);
            // 
            // lblLate
            // 
            this.lblLate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLate.Location = new System.Drawing.Point(0, 0);
            this.lblLate.Name = "lblLate";
            this.lblLate.Size = new System.Drawing.Size(96, 51);
            this.lblLate.TabIndex = 0;
            this.lblLate.Text = "Late By:";
            this.lblLate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dlgOpenSettings
            // 
            this.dlgOpenSettings.FileName = "GraderSettings.xml";
            this.dlgOpenSettings.Filter = "Xml Files|*.xml|All Files|*.*";
            this.dlgOpenSettings.Title = "Open Settings File";
            // 
            // bkgDownload
            // 
            this.bkgDownload.WorkerReportsProgress = true;
            this.bkgDownload.WorkerSupportsCancellation = true;
            this.bkgDownload.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bkgDownload_DoWork);
            this.bkgDownload.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bkgDownload_RunWorkerCompleted);
            this.bkgDownload.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bkgDownload_ProgressChanged);
            // 
            // bkgCompile
            // 
            this.bkgCompile.WorkerReportsProgress = true;
            this.bkgCompile.WorkerSupportsCancellation = true;
            this.bkgCompile.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bkgCompile_DoWork);
            this.bkgCompile.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bkgCompile_RunWorkerCompleted);
            this.bkgCompile.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bkgDownload_ProgressChanged);
            // 
            // bkgUpload
            // 
            this.bkgUpload.WorkerReportsProgress = true;
            this.bkgUpload.WorkerSupportsCancellation = true;
            this.bkgUpload.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bkgUpload_DoWork);
            this.bkgUpload.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bkgUpload_RunWorkerCompleted);
            this.bkgUpload.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bkgDownload_ProgressChanged);
            // 
            // dlgSaveProgList
            // 
            this.dlgSaveProgList.DefaultExt = "*.txt";
            this.dlgSaveProgList.FileName = "programList.txt";
            this.dlgSaveProgList.Filter = "text files|*.txt|All Files|*.*";
            this.dlgSaveProgList.Title = "Save Program List";
            // 
            // dlgSaveStuList
            // 
            this.dlgSaveStuList.DefaultExt = "*.txt";
            this.dlgSaveStuList.FileName = "Stulist.txt";
            this.dlgSaveStuList.Filter = "text files|*.txt|All Files|*.*";
            this.dlgSaveStuList.Title = "Save Student List";
            // 
            // dlgOpenStudent
            // 
            this.dlgOpenStudent.FileName = "stuName.txt";
            this.dlgOpenStudent.Filter = "Text Files|*.txt|All Files|*.*";
            this.dlgOpenStudent.Title = "Open Student List";
            // 
            // dlgOpenProg
            // 
            this.dlgOpenProg.FileName = "ProgList.txt";
            this.dlgOpenProg.Filter = "Text Files|*.txt|All Files|*.*";
            this.dlgOpenProg.Title = "Open Program List";
            // 
            // fldrRemoteDir
            // 
            this.fldrRemoteDir.RootFolder = System.Environment.SpecialFolder.MyComputer;
            // 
            // dlgFindCL
            // 
            this.dlgFindCL.FileName = "CL.exe";
            this.dlgFindCL.InitialDirectory = "wq";
            // 
            // debugStudentToolStripMenuItem
            // 
            this.debugStudentToolStripMenuItem.Name = "debugStudentToolStripMenuItem";
            this.debugStudentToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.debugStudentToolStripMenuItem.Text = "Debug Student";
            this.debugStudentToolStripMenuItem.Click += new System.EventHandler(this.debugStudentToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 462);
            this.Controls.Add(this.SplitContainer1);
            this.Controls.Add(this.StatusStrip1);
            this.Controls.Add(this.MenuStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.SplitContainer1.Panel1.ResumeLayout(false);
            this.SplitContainer1.Panel2.ResumeLayout(false);
            this.SplitContainer1.ResumeLayout(false);
            this.TableLayoutPanel3.ResumeLayout(false);
            this.TableLayoutPanel3.PerformLayout();
            this.ContextMenuStripSelectBy.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.SplitContainer2.Panel1.ResumeLayout(false);
            this.SplitContainer2.Panel2.ResumeLayout(false);
            this.SplitContainer2.ResumeLayout(false);
            this.SplitContainer5.Panel1.ResumeLayout(false);
            this.SplitContainer5.Panel1.PerformLayout();
            this.SplitContainer5.Panel2.ResumeLayout(false);
            this.SplitContainer5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picStuPic)).EndInit();
            this.TableLayoutPanel1.ResumeLayout(false);
            this.SplitContainer3.Panel1.ResumeLayout(false);
            this.SplitContainer3.Panel2.ResumeLayout(false);
            this.SplitContainer3.Panel2.PerformLayout();
            this.SplitContainer3.ResumeLayout(false);
            this.TableLayoutPanel2.ResumeLayout(false);
            this.TableLayoutPanel2.PerformLayout();
            this.SplitContainer4.Panel1.ResumeLayout(false);
            this.SplitContainer4.Panel2.ResumeLayout(false);
            this.SplitContainer4.ResumeLayout(false);
            this.TableLayoutPanel4.ResumeLayout(false);
            this.TableLayoutPanel4.PerformLayout();
            this.contextMenuStripChangeGradeVal.ResumeLayout(false);
            this.contextMenuStripChangeGradeVal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem FileToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem LoadProgramDataToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SaveProgramListToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator5;
        internal System.Windows.Forms.ToolStripMenuItem LoadListOfStudentsToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SaveStudentListToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator6;
        internal System.Windows.Forms.ToolStripMenuItem ChooseHomeFolderToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ChoseRemoteFolderToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator1;
        internal System.Windows.Forms.ToolStripMenuItem SaveSettingsToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem OpenSettingsToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator2;
        internal System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SelecToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SelectAllToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem SelectNoneToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem SelectByLabToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem MondayToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem TuesdayToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem WednesdayToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ThursdayToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem FridayToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SelectByGradeToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SelectGradeToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripTextBox txtToolStripGrade;
        internal System.Windows.Forms.ToolStripMenuItem SelectInversToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SelectUngradedToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem StudentsToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem AddStudentToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem EditSelectedStudentToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem WithDrawFromClassToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ReenrollSelectedInClassToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem DisplayAllGradeToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem GetStudentListFromDirectoryToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem AssignmentToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem AddAssignmentToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem EditSelectedToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator4;
        internal System.Windows.Forms.ToolStripMenuItem DownloadSourcesToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem CompileSourcesToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem GradeSourcesToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem UploadGradesToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ShowtempToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem EmailToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem EmailAssignmentGradeToCheckedToolStripMenuItem;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator3;
        internal System.Windows.Forms.ToolStripTextBox toolStriptxtEmailFrom;
        internal System.Windows.Forms.ToolStripTextBox ToolStriptxtEmailPassword;
        internal System.Windows.Forms.ToolStripMenuItem MiscToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem CopyGradesToClipboardToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem GenerateComparisonDirToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem GenerateStudentsFromRemoteDirToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem EditSettingsToolStripMenuItem;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel lblLocalDir;
        internal System.Windows.Forms.ToolStripStatusLabel lblRemoteDir;
        internal System.Windows.Forms.ToolStripStatusLabel tslblCurrentProg;
        internal System.Windows.Forms.ToolStripStatusLabel tslblCurrentStudent;
        internal System.Windows.Forms.SplitContainer SplitContainer1;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel3;
        internal System.Windows.Forms.ComboBox cmbProglist;
        internal System.Windows.Forms.CheckedListBox chkListStuList;
        internal System.Windows.Forms.CheckBox chkShowWithdrawn;
        internal System.Windows.Forms.CheckBox chkUseFlags;
        internal System.Windows.Forms.CheckBox chkAutoAdvance;
        internal System.Windows.Forms.CheckBox chkAutoDelete;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.TextBox txtCustFlags;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.TextBox txtProgTimeout;
        internal System.Windows.Forms.SplitContainer SplitContainer2;
        internal System.Windows.Forms.SplitContainer SplitContainer5;
        internal System.Windows.Forms.TextBox txtGrade;
        internal System.Windows.Forms.PictureBox picStuPic;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel1;
        internal System.Windows.Forms.SplitContainer SplitContainer3;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel2;
        internal System.Windows.Forms.RadioButton gotoOutput;
        internal System.Windows.Forms.RadioButton gotoCompiler;
        internal System.Windows.Forms.RadioButton gotoCode;
        internal System.Windows.Forms.RadioButton gotoComment;
        internal System.Windows.Forms.TextBox txtMain;
        internal System.Windows.Forms.SplitContainer SplitContainer4;
        internal System.Windows.Forms.TableLayoutPanel TableLayoutPanel4;
        internal System.Windows.Forms.Button grd25;
        internal System.Windows.Forms.Button grd35;
        internal System.Windows.Forms.Button grd45;
        internal System.Windows.Forms.Button grd55;
        internal System.Windows.Forms.Button grd65;
        internal System.Windows.Forms.Button grd75;
        internal System.Windows.Forms.Button grd85;
        internal System.Windows.Forms.Button grd95;
        internal System.Windows.Forms.Button grd0;
        internal System.Windows.Forms.Button cmdNext;
        internal System.Windows.Forms.Button grd10;
        internal System.Windows.Forms.Button grd20;
        internal System.Windows.Forms.Button grd30;
        internal System.Windows.Forms.Button grd40;
        internal System.Windows.Forms.Button grd50;
        internal System.Windows.Forms.Button grd60;
        internal System.Windows.Forms.Button grd70;
        internal System.Windows.Forms.Button grd80;
        internal System.Windows.Forms.Button grd90;
        internal System.Windows.Forms.Button grd100;
        internal System.Windows.Forms.Button cmdPrev;
        internal System.Windows.Forms.TextBox grdCustom;
        internal System.Windows.Forms.ContextMenuStrip ContextMenuStripSelectBy;
        internal System.Windows.Forms.ToolStripMenuItem SelectAllToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SelectNoneToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SelectInverseToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem SelectLab1ToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem MondayToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem TuesdayToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem WednesdayToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem ThursdayToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem FridayToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem SelectGradedToolStripMenuItem;
        internal System.Windows.Forms.OpenFileDialog dlgOpenSettings;
        internal System.ComponentModel.BackgroundWorker bkgDownload;
        internal System.ComponentModel.BackgroundWorker bkgCompile;
        internal System.ComponentModel.BackgroundWorker bkgUpload;
        internal System.Windows.Forms.SaveFileDialog dlgSaveProgList;
        internal System.Windows.Forms.SaveFileDialog dlgSaveStuList;
        internal System.Windows.Forms.OpenFileDialog dlgOpenStudent;
        internal System.Windows.Forms.OpenFileDialog dlgOpenProg;
        internal System.Windows.Forms.FolderBrowserDialog fldrLocalDir;
        internal System.Windows.Forms.FolderBrowserDialog fldrRemoteDir;
        internal System.Windows.Forms.OpenFileDialog dlgFindCL;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripChangeGradeVal;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBoxNewGrade;
        private System.Windows.Forms.ToolStripMenuItem launchCmdPromptToolStripMenuItem;
        private System.Windows.Forms.Label lblLate;
        private System.Windows.Forms.ToolStripMenuItem selectByGradeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem selectToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripMenuItem rerunSelectedStudentONLYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem debugStudentToolStripMenuItem;
    }
}

