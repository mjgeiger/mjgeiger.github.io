//
//  sched_sim.c
//  
//  EECE.4810/5730
//  Dr. Michael Geiger
//  4/4/18
//	Scheduling simulator project
//
//  Function definitions

#include <stdlib.h>
#include <string.h>
#include "sched_sim.h"		// Implicitly includes <stdio.h>

// Add node pointed to by newN to queue pointed to by Q,
//   with algo determining scheduling algorithm
void Qadd(Queue *Q, QNode *newN, char algo) {
	QNode *prev, *cur;		// Node pointers
	
	if (Q->first == NULL) {	// Queue empty--simply add one node
		Q->first = Q->last = newN;
		newN->next = NULL;
	}
	
	// Non-empty queue--find appropriate spot based on algorithm
	else if (algo == 'F' || algo == 'R') {		// FCFS, RR--new addition always goes at end of queue
		Q->last->next = newN;
		newN->next = NULL;
		Q->last = newN;
	}
	
	else {
		prev = NULL;
		cur = Q->first;
		
		switch (algo) {
			case 'S':		// SJF/STCF--sort based on burst
				while (cur != NULL && (cur->burst <= newN->burst || cur->loading == 1)) {
					prev = cur;
					cur = cur->next;
				}
				break;
				
			case 'P':		// Priority--sort based on priority
				while (cur != NULL && (cur->priority <= newN->priority || cur->loading == 1)) {
					prev = cur;
					cur = cur->next;
				}
				break;
				
			case 'D':		// Process done--sort based on pid
				while (cur != NULL && cur->pid < newN->pid) {
					prev = cur;
					cur = cur->next;
				}
				break;
			
			default:
				printf("You're trying to use WHAT algorithm to add a node?!?\n");
				return;
		}
		
		newN->next = cur;	// cur always points to what follows new node (even if cur == NULL)
		
		if (prev == NULL)			// New node is first--just update first pointer
			Q->first = newN;
		else if (cur == NULL) {		// New node is last
			Q->last->next = newN;	//   old "last" node points to new node, then
			Q->last = newN;			//   queue's last pointer points to new node
		}
		else						// Node is somewhere in middle
			prev->next = newN;
	}
}

// Remove node from front of ready queue
QNode *dequeue(Queue *Q) {
	QNode *n = Q->first;			// Get pointer to first node in queue--will return

	if (n != NULL) {					// If queue is not empty
		Q->first = Q->first->next;	// Old 2nd node is now 1st node
	
		if (Q->first == NULL)			// If only one node in queue, queue now empty
			Q->last = NULL;
	}
	return n;
}

// Print contents of ready queue pointed to by Q
void printQ(FILE *fp, char *qtype, Queue *Q) {
	QNode *n = Q->first;		// Start with first node
	
	fprintf(fp, "%s queue: ", qtype);
	
	if (n == NULL)
		fprintf(fp, "empty\n");
	
	else {		// Print contents of non-empty queue
		do {
			fprintf(fp, "%u", n->pid);
			n = n->next;
			if (n != NULL)
				fprintf(fp, "-");	// Print dash between nodes if >= 1 left
		} while (n != NULL);
		fprintf(fp, "\n");
	}
}

// Clean up ready queue pointed to by Q--delete
//   all nodes
void cleanQ(Queue *Q) {
	QNode *prev, *cur;		// Node pointers
	
	// Visit all nodes and delete them if list is non-empty
	if (Q->first != NULL) {
		prev = Q->first;			// Start with first node
		cur = Q->first->next;		//   and second node (if there is one)
		
		if (cur == NULL)			// Only one node in list
			free(prev);
		
		else {						// >1 node in list
			do {
				free(prev);
				prev = cur;
				cur = cur->next;
			} while (cur != NULL);
		}
	}
	Q->first = Q->last = NULL;		// Indicate queue is empty
}

// Allocate node and error check to make sure it works
QNode *allocNode() {
	QNode *n = (QNode *)malloc(sizeof(QNode));
	if (n == NULL)
		printf("malloc() didn't work ... time to give up\n");
	return n;
}

// Runs main simulation loop for algorithm specified
//   by algo, using arrival list pointed to by AQ and
//   generating snapshots every "interval" cycles
// Statistics stored in struct pointed to by algoStats
// Output to file pointed to by fp
void simLoop(Queue *AQ, char *algoS, unsigned interval, Stats *algoStats, FILE *fp) {
	Queue ReadyQ = {NULL, NULL};	// Ready queue
	Queue DoneQ  = {NULL, NULL};	// Queue of completed processes
	QNode *cur = NULL;				// Currently executing process
	QNode *hack = NULL;				// Node for awful cycle 0 ready queue output hack
	char *sched = NULL;				// "Schedule" of processes used in final output
	char buf[10];					// Character buffer
	unsigned cycle = 0;				// Simulation cycle
	unsigned lastCS = 0;			// Cycle of last context switch
	char RRswitch = 0;				// ***Hack to fix RR wait time
	unsigned nproc = 0;				// Number of processes
	
	fprintf(fp, "***** %s Scheduling *****\n", algoS);
	
	do {
		
		// For all processes with arrival matching current cycle,
		//   dequeue from arrival queue and add to ready queue
		while (AQ->first != NULL &&
			   AQ->first->arrival == cycle) {
			
			// To make RR work correctly, must mark new arrival
			//   as "context switch" 2 cycles earlier if ready
			//   queue was empty when new task arrived
			// Just make sure first job has gotten at least 2 cycles!
			if (ReadyQ.first == NULL && cycle >= 2) {
				lastCS = cycle - 2;
				RRswitch = 1;
			}
			
			Qadd(&ReadyQ, dequeue(AQ), algoS[0]);
		}
		
		// If no current process, dequeue first thing in ready queue
		//   and update some fields accordingly
		if (cur == NULL) {
			cur = dequeue(&ReadyQ);
			
			if (cur->qtime > cycle)	cur->qtime--;	// Account for process taken out of queue at time 0
			
			cur->wait += cycle - cur->qtime;	// cur->qtime = time process arrived in ReadyQ
			cur->next = NULL;					// Node isn't in queue--shouldn't point to anything else
			cur->loading = 0;					// Node is already loaded--shouldn't be marked as loading
			
			// Update schedule string
			sprintf(buf, "%u", cur->pid);		// Turn current PID into string
			if (sched == NULL) {				// First thing on schedule
				sched = (char *)malloc(strlen(buf) + 1);
				strcpy(sched, buf);
			}
			else {								// Adding new PID to existing schedule
				sched = (char *)realloc(sched,
										strlen(sched) + strlen(buf) + 2);
				sprintf(sched, "%s-%s", sched, buf);
			}
			
			algoStats->perfData[2]++;		// Increment # context switches
		}
		
		// Operate on current node--decrease remaining burst time as long as process can actually start
		if (cycle > cur->arrival)  cur->burst--;
		
		// Print cycle
		if (cycle % interval == 0)
			fprintf(fp, "t = %u\n", cycle);
		
		// Special case--always loading on first cycle
		if (cycle == 0) {
			fprintf(fp, "CPU: Loading process %u (CPU burst = %u)\n",
					cur->pid, cur->burst);
			
			/*** TOTAL HACK TO MAKE CYCLE 0 READY QUEUE OUTPUT LOOK RIGHT ***/
			fprintf(fp, "Ready queue: %u", cur->pid);
			hack = ReadyQ.first;
			while (hack != NULL) {
				fprintf(fp, "-%u", hack->pid);
				hack = hack->next;
			}
			fprintf(fp, "\n");
		}
		
		// Process finishing this cycle--print appropriate output,
		//   then move to done queue and reset cur to NULL
		else if (cur->burst == 0) {
			if (cycle % interval == 0)
				fprintf(fp, "CPU: Finishing process %u", cur->pid);

			// If there's something to load, load it
			if (ReadyQ.first != NULL) {
				if (cycle % interval == 0)
					fprintf(fp, "; loading process %u (CPU burst = %u)",
							ReadyQ.first->pid, ReadyQ.first->burst);
				ReadyQ.first->loading = 1;
			}
			if (cycle % interval == 0)	fprintf(fp, "\n");
			
			cur->turn = cycle - cur->arrival;	// Calculate turnaround time
			
			Qadd(&DoneQ, cur, 'D');				// Move to "done queue"--will walk at end to calculate stats
			cur = NULL;
			
			/*** Hack to make RR ready queue output make sense ***/
			if (cycle % interval == 0)	printQ(fp, "Ready", &ReadyQ);

			lastCS = cycle;			// Mark this cycle as time of last context switch
									//   Used for round robin
		}
		
		// Handling preemption
		// STCF--if front of ready queue has lower burst time, switching next cycle
		// RR--preempt job every two cycles
		else if (ReadyQ.first != NULL &&
				 ((strcmp(algoS, "STCF") == 0 && ReadyQ.first->burst < cur->burst) ||
				 (strcmp(algoS, "Round robin") == 0 && (cycle - lastCS) == 2))) {
		
			if (cycle % interval == 0)
				fprintf(fp, "CPU: Preempting process %u (remaining CPU burst = %u); loading process %u (CPU burst = %u)\n",
						cur->pid, cur->burst, ReadyQ.first->pid, ReadyQ.first->burst);
			ReadyQ.first->loading = 1;
			
			cur->qtime = cycle + 1;		// Mark current process as returning to ready queue in next cycle so wait time added
			
			/*** Hack to make RR ready queue output make sense ***/
			if (cycle % interval == 0)	printQ(fp, "Ready", &ReadyQ);
			
			Qadd(&ReadyQ, cur, algoS[0]);	// Return current job to ready queue
			cur = NULL;
					 
			lastCS = cycle;			// Mark this cycle as time of last context switch
									//   Used for round robin
		}
		
		// Normal state--in the middle of running a process without end or preemption
		else if (cycle % interval == 0)
			fprintf(fp, "CPU: Running process %u (remaining CPU burst = %u)\n",
					cur->pid, cur->burst);
		
		/*** Hack to make RR ready queue output make sense ***/
		if (cycle % interval == 0 && lastCS != cycle)
			printQ(fp, "Ready", &ReadyQ);
	
		if (cycle % interval == 0)	fprintf(fp, "\n");
		
		cycle++;
		
	} while (ReadyQ.first != NULL || AQ->first != NULL || cur != NULL);	// Repeat as long as something is queued or running
	
	// Print algorithm summary while calculating stats
	fprintf(fp, "*********************************************************\n");
	fprintf(fp, "%s Summary (WT = wait time, TT = turnaround time):\n\n", algoS);
	fprintf(fp, "PID     WT     TT\n");
	
	cur = DoneQ.first;
	while (cur != NULL) {
		algoStats->perfData[0] += cur->wait;
		algoStats->perfData[1] += cur->turn;
		fprintf(fp, "%2u %7u %6u\n", cur->pid, cur->wait, cur->turn);
		cur = cur->next;
		nproc++;
	}
	algoStats->perfData[0] /= nproc;	// Average wait time
	algoStats->perfData[1] /= nproc;	// Average turnaround time
	fprintf(fp, "AVG %6.2lf %6.2lf\n\n",
			algoStats->perfData[0],
			algoStats->perfData[1]);
	
	fprintf(fp, "Process sequence: %s\n", sched);
	fprintf(fp, "Context switches: %.0lf\n\n\n", algoStats->perfData[2]);
	
	// After processing done queue for stats, clean up
	cleanQ(&DoneQ);
	
	// Clean up dynamically allocated locals
	free(sched);
}

// Sort statistics array by given index, then print summary table to file
//  Index 0 = avg wait time, 1 = avg turnaround time, 2 = context switches
void statSort(Stats stList[5], unsigned index, char *metric, FILE *fp) {
	unsigned i, j;	// Loop indexes
	Stats temp;		// Temporary statistics structure
	
	// Uses insertion sort to order list
	for (i = 1; i < 5; i++) {
		for (j = i; j > 0 && stList[j].perfData[index] < stList[j-1].perfData[index]; j--) {
			temp = stList[j];
			stList[j] = stList[j-1];
			stList[j-1] = temp;
		}
	}
	
	// Print newly ordered list
	fprintf(fp, "%s Comparison\n", metric);
	
	for (i = 0; i < 5; i++)
		fprintf(fp, "%u %-12s %*.*lf\n",
				i + 1, stList[i].algName,
				(index == 2 ? 3 : 6),			// Use field width 3 & precision 0 for context switches
				(index == 2 ? 0 : 2),			// Field width 6 & precision 2 otherwise
				stList[i].perfData[index]);
	fprintf(fp, "\n");
}


