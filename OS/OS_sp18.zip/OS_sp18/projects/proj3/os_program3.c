//
//  os_program3.c
//  
//  EECE.4810/5730
//  Dr. Michael Geiger
//  4/4/18
//	Scheduling simulator project
//
//  Main function
//   Note that program is invoked as:
//      <executable> <infile> <outfile> <interval>
//   where the arguments are as follows:
//      <executable>: program name
//      <infile>: name of text file containing information
//                (CPU burst, priority, arrival time) about
//				  processes to be simulated
//		<outfile>: name of text file containing simulator
//				   output
//		<interval>: # of cycles between simulation snapshots

#include <stdlib.h>
#include "sched_sim.h"		// Implicitly includes <stdio.h>

int main (int argc, char *argv[])
{
	FILE *infile, *outfile;				// Input/output file pointers
	unsigned burst, pri, arr;			// Input values for CPU burs, priority, and arrival time
	unsigned intvl;						// Interval to generate
	unsigned i;							// Loop index
	
	// Arrival queues--process lists in arrival order
	Queue AQ_FCFS = {NULL, NULL};		// FCFS arrival queue
	Queue AQ_SJF =  {NULL, NULL};		// SJF arrival queue
	Queue AQ_STCF = {NULL, NULL};		// STCF arrival queue
	Queue AQ_RR =   {NULL, NULL};		// RR arrival queue
	Queue AQ_PRI =  {NULL, NULL};		// PRI arrival queue
	
	// Node pointers for allocating new nodes
	QNode *FCFS_node, *SJF_node, *STCF_node, *RR_node, *PRI_node;
	
	// Algorithm statistics structures
	// algoStats[0] = FCFS, algoStats[1] = SJF, algoStats[2] = STCF
	//   algoStats[3] = RR, algoStats[4] = priority
	Stats algoStats[5] =
		{	{"FCFS",        0, 0, 0},
			{"SJF",         0, 0, 0},
			{"STCF",        0, 0, 0},
			{"Round robin", 0, 0, 0},
			{"Priority",    0, 0, 0}	};
	
	// Open input file
	infile = fopen(argv[1], "r");
	if (infile == NULL) {
		printf("Error: could not open %s\n", argv[1]);
		return 0;
	}
	
	// Read input file and build arrival queues
	i = 0;
	while (fscanf(infile, "%u %u %u", &burst, &pri, &arr) != EOF) {
		
		// Allocate 5 new nodes, one for each algorithm
		FCFS_node = allocNode();
		SJF_node = allocNode();
		STCF_node = allocNode();
		RR_node = allocNode();
		PRI_node = allocNode();
		
		// If any node is NULL, clean up and exit
		if (FCFS_node == NULL || SJF_node == NULL || STCF_node == NULL ||
			RR_node == NULL || PRI_node == NULL) {
			printf("Error: could not allocate arrival node\n");
			cleanQ(&AQ_FCFS);
			cleanQ(&AQ_SJF);
			cleanQ(&AQ_STCF);
			cleanQ(&AQ_RR);
			cleanQ(&AQ_PRI);
			return 0;
		}
		
		// Copy new data into one node
		FCFS_node->pid = i;
		FCFS_node->burst = burst;
		FCFS_node->priority = pri;
		FCFS_node->arrival = arr;
		FCFS_node->qtime = arr + 1;
		FCFS_node->wait = FCFS_node->turn = 0;
		FCFS_node->loading = 0;
		FCFS_node->next = NULL;
		
		// Copy that node to others
		*SJF_node = *STCF_node = *RR_node = *PRI_node = *FCFS_node;
	
		// Add each node to appropriate arrival queue
		// Using 'F' as algorithm argument since arrival queue is in FCFS order
		Qadd(&AQ_FCFS, FCFS_node, 'F');
		Qadd(&AQ_SJF,  SJF_node,  'F');
		Qadd(&AQ_STCF, STCF_node, 'F');
		Qadd(&AQ_RR,   RR_node,   'F');
		Qadd(&AQ_PRI,  PRI_node,  'F');
		
		i++;
	}
	fclose(infile);
	
	// Open output file
	outfile = fopen(argv[2], "w");
	if (outfile == NULL) {			// If failure, must clean up arrival queues to avoid memory leak
		printf("Error: could not open %s\n", argv[2]);
		cleanQ(&AQ_FCFS);
		cleanQ(&AQ_SJF);
		cleanQ(&AQ_STCF);
		cleanQ(&AQ_RR);
		cleanQ(&AQ_PRI);
		return 0;
	}
	
	// Run simulations for each algorithm using simLoop function
	// This function should empty arrival queue so there's no need
	//   to clean up dynamically allocated data out here
	intvl = (unsigned) atoi(argv[3]);
	
	simLoop(&AQ_FCFS, "FCFS",        intvl, &algoStats[0], outfile);
	simLoop(&AQ_SJF,  "SJF",		 intvl, &algoStats[1], outfile);
	simLoop(&AQ_STCF, "STCF",        intvl, &algoStats[2], outfile);
	simLoop(&AQ_RR,   "Round robin", intvl, &algoStats[3], outfile);
	simLoop(&AQ_PRI,  "Priority",    intvl, &algoStats[4], outfile);
	
	// Generate overall summary
	fprintf(outfile, "***** OVERALL SUMMARY *****\n\n");
	statSort(algoStats, 0, "Wait Time", outfile);
	statSort(algoStats, 1, "Turnaround Time", outfile);
	statSort(algoStats, 2, "Context Switch", outfile);
}