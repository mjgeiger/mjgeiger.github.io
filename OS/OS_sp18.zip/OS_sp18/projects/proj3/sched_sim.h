//
//  sched_sim.h
//
//  EECE.4810/5730
//  Dr. Michael Geiger
//  4/4/18
//	Scheduling simulator project
//
//  Header file containing structure definitions
//    and function prototypes (queue access,
//    main simulation loop)

#ifndef sched_sim_h
#define sched_sim_h

#include <stdio.h>

/** STRUCTURE DEFINITIONS **/

// Queue node structure--contains information
//   about each process in queue
typedef struct QN {
	unsigned pid;		// Process ID
	unsigned burst;		// CPU burst time remaining
	unsigned priority;	// Current priority (lower # = higher priority)
	unsigned arrival;	// Arrival time
	unsigned qtime;		// Time process is placed in ready queue to wait
	unsigned wait;		// Wait time
	unsigned turn;		// Turnaround time
	char loading;		// Indicates if node is next to execute
	struct QN *next;	// Pointer to next node in queue
} QNode;

// Actual queue--structure defined so it's easier
//   to pass to functions
typedef struct {
	QNode *first;		// First node
	QNode *last;		// Last node
} Queue;

// Structure for tracking algorithm stats
typedef struct {
	char algName[15];	// Algorithm name
	double perfData[3];	// Data about algorithm performance
						//   perfData[0] = average wait time
						//   perfData[1] = average turnaround time
						//   perfData[2] = total context switches
} Stats;

/** FUNCTION PROTOTYPES **/

// Add node pointed to by newN to queue pointed to by Q,
//   with algo determining scheduling algorithm
void Qadd(Queue *Q, QNode *newN, char algo);

// Remove node from front of ready queue
QNode *dequeue(Queue *Q);

// Print contents of queue described by qtype and pointed to by Q
void printQ(FILE *fp, char *qtype, Queue *Q);

// Clean up queue pointed to by Q--delete all nodes
void cleanQ(Queue *Q);

// Allocate node and error check to make sure it works
//   "Gracefully" exit if not
QNode *allocNode();

// Runs main simulation loop for algorithm specified
//   by algo, using arrival list pointed to by AQ and
//   generating snapshots every "interval" cycles
// Statistics stored in struct pointed to by algoStats
void simLoop(Queue *AQ, char *algoS, unsigned interval, Stats *algoStats, FILE *fp);

// Sort statistics array by given index
//  Index 0 = avg wait time, 1 = avg turnaround time, 2 = context switches
void statSort(Stats stList[5], unsigned index, char *metric, FILE *fp);

#endif /* sched_sim_h */
