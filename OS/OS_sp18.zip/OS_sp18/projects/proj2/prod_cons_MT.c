//
//  prod_cons_MT.c
//  
//  EECE.4810/5730
//  Dr. Michael Geiger
//  2/24/18
//	Multithreaded producer-consumer
//    problem with bounded buffer
//
//  Header file containing structure definitions
//    and producer/consumer function prototypes

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include "prod_cons_MT.h"

extern TSBuffer buf;

// Producer routine
// Repeatedly writes random value to buffer when empty
void *TSB_producer(void *a)
{
	int i;		// Loop index
	
	// FORCE WAIT UNTIL ALL CREATED?
	
	PCArg *arg;
	arg = (PCArg *)a;
	printf("P%u: Producing %u values\n", arg->tnum, arg->nval);
	
	// Write values to buffer
	for (i = 0; i < arg->nval; i++) {
		pthread_mutex_lock(&buf.lock);
		
		while (buf.count == buf.size) {
			printf("P%u: Blocked due to full buffer\n", arg->tnum);
			pthread_cond_wait(&buf.fullCV, &buf.lock);
			printf("P%u: Done waiting on full buffer\n", arg->tnum);
		}
		
		// Write new value to buffer
		buf.buffer[buf.inpos] = (rand() % 10) + 1;
		printf("P%u: Writing %d to position %u\n", arg->tnum, buf.buffer[buf.inpos], buf.inpos);
		buf.inpos = (buf.inpos + 1) % buf.size;
		buf.count++;
		
		// If buffer was empty, wake up one waiting thread
		if (buf.count == 1)
			pthread_cond_signal(&buf.emptyCV);
		
		pthread_mutex_unlock(&buf.lock);
	}
	
	printf("P%u: Exiting\n", arg->tnum);
	pthread_exit((void*) a);
}

// Consumer routine
void *TSB_consumer(void *a)
{
	int i;		// Loop index
	
	// FORCE WAIT UNTIL ALL CREATED?
	
	PCArg *arg;
	arg = (PCArg *)a;
	printf("C%u: Consuming %u values\n", arg->tnum, arg->nval);
	
	for (i = 0; i < arg->nval; i++) {
		pthread_mutex_lock(&buf.lock);
		
		// If positions match and not full, buffer is empty
		while (buf.count == 0) {
			printf("C%u: Blocked due to empty buffer\n", arg->tnum);
			pthread_cond_wait(&buf.emptyCV, &buf.lock);
			printf("C%u: Done waiting on empty buffer\n", arg->tnum);
		}
		
		// Read value from buffer
		printf("C%u: Reading %d from position %u\n", arg->tnum, buf.buffer[buf.outpos], buf.outpos);
		buf.outpos = (buf.outpos + 1) % buf.size;
		buf.count--;
		
		// If buffer was full, wake up one waiting thread
		if (buf.count == buf.size - 1)
			pthread_cond_signal(&buf.fullCV);
		
		pthread_mutex_unlock(&buf.lock);
	}
	
	printf("C%u: Exiting\n", arg->tnum);
	pthread_exit((void*) a);
}
