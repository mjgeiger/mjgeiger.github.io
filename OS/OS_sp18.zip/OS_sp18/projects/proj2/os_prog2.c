//
//  os_prog2.c
//  
//  EECE.4810/5730
//  Dr. Michael Geiger
//  2/24/18
//	Multithreaded producer-consumer
//    problem with bounded buffer
//
//  Main function

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "prod_cons_MT.h"

TSBuffer buf;		// Global thread-safe buffer to be used by all threads

/************
 FUTURE DIRECTION: FORCE ALL THREADS TO WAIT UNTIL ALL CREATED,
 THEN BROADCAST TO ALL SO THEY WAKE UP AND START COMPETING FOR RESOURCES
 ************/

int main (int argc, char *argv[])
{
	pthread_t *threads;		// Array of thread IDs
	PCArg *tArgs;			// Array of thread arguments
	pthread_attr_t attr;	// Attribute structure
	int bufSize;			// Size of buffer
	int nProd, nCons;		// Number of producers/consumers
	int rv;					// Return value for pthread functions
	unsigned i;				// Loop index
	unsigned totVals;		// Total values produced/consumed
	void *status;			// Return status
	
	// Seed random number generator
	srand(time(0));
	
	// Collect command line arguments
	bufSize = atoi(argv[1]);
	nProd = atoi(argv[2]);
	nCons = atoi(argv[3]);
	
	// Initialize buffer structure--holds bufSize values,
	//   is initially not full, and in/out positions both 0
	buf.size = bufSize;
	buf.inpos = buf.outpos = 0;
	buf.count = 0;
	buf.buffer = (int *)calloc(bufSize, sizeof(int));
	if (buf.buffer == NULL) {
		printf("Could not allocate buffer\n");
		return 0;
	}
	pthread_mutex_init(&buf.lock, NULL);
	pthread_cond_init(&buf.fullCV, NULL);
	pthread_cond_init(&buf.emptyCV, NULL);
	
	// Initialize and set thread detached attribute
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	
	// Allocate space for storing thread IDs
	threads = (pthread_t *)malloc((nProd + nCons) * sizeof(pthread_t));
	if (threads == NULL) {
		printf("Could not allocate TID array\n");
		return 0;
	}
	
	// Allocate space for storing thread arguments
	tArgs = (PCArg *)malloc((nProd + nCons) * sizeof(PCArg));
	if (tArgs == NULL) {
		printf("Could not allocate thread argument array\n");
		return 0;
	}

	// Start producer threads
	// Set up argument structure, then create
	// Each producer produces enough data to fill the buffer twice
	for (i = 0; i < nProd; i++) {
		tArgs[i].tnum = i;
		tArgs[i].nval = 2 * bufSize;
		rv = pthread_create(&threads[i], NULL, TSB_producer, (void *)&tArgs[i]);
		if (rv) {
			printf("ERROR: return from pthread_create is %d\n", rv);
			return 0;
		}
		printf("Main: started producer %d\n", i);
	}
	
	// Start consumer threads
	// Set up argument structure, then create
	totVals = 2 * bufSize * nProd;
	for (i = nProd; i < nProd + nCons; i++) {
		tArgs[i].tnum = i - nProd;
		
		// Determine # values for each consumer to read
		//   Divide evenly but make last consumer take extras
		if (i == nProd + nCons - 1)
			tArgs[i].nval = totVals / nCons + totVals % nCons;
		else
			tArgs[i].nval = totVals / nCons;
		
		rv = pthread_create(&threads[i], NULL, TSB_consumer, (void *)&tArgs[i]);
		if (rv) {
			printf("ERROR: return from pthread_create is %d\n", rv);
			return 0;
		}
		printf("Main: started consumer %d\n", i - nProd);
	}
	
	// Wait for producing threads to join
	for (i = 0; i < nProd; i++) {
		rv = pthread_join(threads[i], &status);
		if (rv) {
			printf("ERROR: return from pthread_join() is %d\n", rv);
			return 0;
		}
		printf("Main: producer %u joined\n", ((PCArg *)status)->tnum);
	}
	
	// Wait for consuming threads to join
	for (i = nProd; i < nProd + nCons; i++) {
		rv = pthread_join(threads[i], &status);
		if (rv) {
			printf("ERROR: return from pthread_join() is %d\n", rv);
			return 0;
		}
		printf("Main: consumer %u joined\n", ((PCArg *)status)->tnum);
	}
	
	// Cleanup--destroy attribute, mutex, and CVs,
	//   and deallocate dynamically allocated memory
	pthread_attr_destroy(&attr);
	pthread_mutex_destroy(&buf.lock);
	pthread_cond_destroy(&buf.fullCV);
	pthread_cond_destroy(&buf.emptyCV);
	free(buf.buffer);
	free(threads);
	free(tArgs);
	
	printf("Main: program completed\n");
	pthread_exit(NULL);
}