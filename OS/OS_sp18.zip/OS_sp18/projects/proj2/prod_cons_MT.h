//
//  prod_cons_MT.h
//  
//  EECE.4810/5730
//  Dr. Michael Geiger
//  2/24/18
//	Multithreaded producer-consumer
//    problem with bounded buffer
//
//  Header file containing structure definitions
//    and producer/consumer function prototypes

#ifndef prod_cons_MT_h
#define prod_cons_MT_h

// Thread-safe buffer structure
typedef struct {
	int *buffer;				// Actual array
	unsigned inpos, outpos;		// Positions for input, output
	unsigned size;				// Total size of buffer
	unsigned count;				// # values in buffer
	pthread_mutex_t lock;		// Lock for buffer
	pthread_cond_t fullCV;		// Buffer full condition variable
	pthread_cond_t emptyCV;		// Buffer empty condition variable
} TSBuffer;

// Producer/consumer function argument structure
typedef struct {
	unsigned tnum;	// Thread "number"
	unsigned nval;	// Number of values to
					//   be written to/read from buffer
} PCArg;

// Function prototypes for producer/consumer functions
void *TSB_producer(void *arg);
void *TSB_consumer(void *arg);

#endif /* prod_cons_MT_h */
