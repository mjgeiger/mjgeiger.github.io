#include "semoperations.h" 

//gets the semaphore for the given key
//if the semaphore exists, that semid is returened, if not a new
//semid is returned
int initsem(key_t semkey) 
{
	int status = 0, semid;

	if ( (semid = semget(semkey, 1, 0600 | IPC_CREAT | IPC_EXCL)) == -1)
	{
		if (errno == EEXIST)
			semid = semget(semkey, 1, 0);
	}
	else 
	{
		senum arg;
		arg.val = 1;
		status = semctl(semid, 0, SETVAL, arg);

	}

	if (semid == -1 || status == -1)
	{
		perror("initsem");
		return -1;
	}
	return semid;

}

//signals the sem (increments) same as release() or v()
void signal(int semid)
{
	struct sembuf buf;

	buf.sem_num = 0;
	buf.sem_op = 1;
	buf.sem_flg = SEM_UNDO;

	if( (semop(semid, &buf, 1)) == -1)
	{
		perror("signal");
		exit(1);
	}
}

//waits on the sem (decrements) same as wait() or p()
void wait_s(int semid)
{
	struct sembuf buf;

	buf.sem_num = 0;
	buf.sem_op = -1;
	buf.sem_flg = SEM_UNDO;

	if( (semop(semid, &buf, 1)) ==-1)
	{
		perror("wait");
		exit(1);
	}
}
