/*
*	CIS 370 Project 2 Phase 3
*	Neal Charbonneau
*	12/10/06
*
*
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <time.h>
#include "semoperations.h"
#define LIMIT 500000  //number of times each child increments count
#define OUT stdout    //what output will be written to
#define NUM_PROCS 3  //number of children

typedef struct
{
   int value;
}  shared_mem;

shared_mem   *counter;


//function called by each child. gets the semaphore and increments the count LIMIT times
void process(int semid, int child_num)
{
	clock_t start, stop;
	double elapsed;
	int i;

	fprintf(OUT, "Hello from child %d. Process ID: %d, Parent Process: %d\n", child_num, getpid(), getppid());
	start = clock();
			
	for (i = 0; i < LIMIT; i++)
	{
		wait_s(semid);
		counter->value = counter->value + 1;
		signal(semid);
	}
	
	
	stop = clock();
	elapsed = ( (double)(stop - start) ) / CLOCKS_PER_SEC;
	fprintf(OUT, "Child %d finished in %.3f seconds. Value of counter: %d\n",child_num, elapsed, counter->value);


	

}

/*   main method */

main()
{
	key_t		key = IPC_PRIVATE, semkey = 0x200;  /* shared memory key */
	int		shmid, semid;      /* shared memory ID */
	shared_mem	*shmat1;   /* function to allocate shared memory */
	int		pid1;	    /* process id for child1 */
	int		pid2;	    /* process id for child2 */
	int 		pid3;
	int 		i, status;
	clock_t 	start, stop;
	double 		elapsed;

	start = clock();	
	/* attempts to attach to an existing memory segment	*/
	if (( shmid = shmget(key, sizeof(int), IPC_CREAT | 0666)) < 0)
	{
	     perror("shmget");
	     exit(1);
	}
		/*attempts the shared memory segment	*/
	if((counter = (shared_mem *)shmat(shmid, NULL, 0)) == (shared_mem *) -1)
	{
		perror("shmat");
		exit(1);
	}
	/*initializing shared memory to 0 */
	 
	counter->value = 0;
	
	if ( (semid = initsem(semkey)) <0)
	{
		perror("semaphore");
		exit(1);
	} 

	//loops to create child processes and uses generic process function instead of using 3 switch statements
	for (i = 0; i < NUM_PROCS; i++)
	{
		switch(fork()) {
			case -1:
				perror("fork");
				exit(1);
			case 0: //child process
				process(semid, i+1);
				return 0;
			default: 
				break;
		}
	}
	/* parent waits (use wait();) for child processes to finish. */
	//wait for all 3 children
	for (i = 0; i < NUM_PROCS; i++)
		wait(NULL);
	

	/* parent process reports value of counter */
	/* parent process exits safely */
	
	/*deallocate shared memory */
	if(shmctl(shmid, IPC_RMID, (struct shmid_ds *)0)== -1){
	    perror("shmctl");
	    exit(-1);
	}
	


	stop = clock();
	elapsed = ( (double)(stop - start) ) / CLOCKS_PER_SEC;
	printf("Parent finished in %.4f seconds. Value of counter: %d\n", elapsed, counter->value);
	exit(0);

}
