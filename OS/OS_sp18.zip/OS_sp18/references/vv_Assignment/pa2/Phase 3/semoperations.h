#include <sys/sem.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <stdlib.h>
typedef union _senum {

	int val;
	struct semid_ds *buf;
	ushort *array;
} senum;

int initsem(key_t);
void wait_s(int);
void signal(int);
