#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <time.h>
#define LIMIT 1000000  //number of times each child increments the counter
#define OUT stdout     //where output is written to


typedef struct
{
   int value;
}  shared_mem;

shared_mem   *counter;

/* This fcn should increase the value of the shared variable "counter" all the way
up to 50000 */

process1()
{
	int i;
	clock_t start, stop;
	double elapsed;

	fprintf(OUT, "Hello from child 1. Process ID: %d, Parent ID: %d\n", getpid(), getppid());
	start = clock();
	
	for (i = 0; i < LIMIT; i++)
	{
		counter->value = counter->value + 1;
	}
	stop = clock();
	elapsed = ( (double)(stop - start) ) / CLOCKS_PER_SEC;
	

	fprintf(OUT, "Child 1 finished in %.8f seconds. Value of counter: %d\n", elapsed, counter->value);
		
	
}

/* This fcn should also increase the value of the shared memory variable "counter" all the way
up to 50000 */

process2()
{
	int i;
	clock_t start, stop;
	double elapsed;

	fprintf(OUT, "Hello from child 2. Process ID: %d, Parent ID: %d\n", getpid(), getppid());
	start = clock();
	for (i = 0; i < LIMIT;i++)
	{
		counter->value = counter->value + 1;
	}
	stop = clock();
	elapsed = ( (double)(stop - start) ) / CLOCKS_PER_SEC;
	fprintf(OUT, "Child 2 finished in %.8f seconds. Value of counter: %d\n", elapsed, counter->value);
	

}

/*		The Main Body					*/

main()
{
	key_t		key = IPC_PRIVATE;  /* shared memory key */
	int		shmid;      /* shared memory ID */
	int		pid1;	    /* process id for child1 */
	int		pid2;	    /* process id for child2 */
	clock_t 	start, stop;
	double 		elapsed;

	start = clock();	
	/* attempts to attach to an existing memory segment	*/
	if (( shmid = shmget(key, sizeof(int), IPC_CREAT | 0666)) < 0)
	{
	     perror("shmget");
	     exit(1);
	}
		/*attempts the shared memory segment	*/
	if((counter = (shared_mem *)shmat(shmid, NULL, 0)) == (shared_mem *) -1)
	{
		perror("shmat");
		exit(1);
	}
		/*initializing shared memory to 0 */
	 
	 counter->value = 0;

	
	/* fork process one here */
	switch (pid1 = fork()) {
		case -1:
			perror("fork");
			exit(1);
		case 0:
			process1();
			return 0;
		default:
			break;
	}
	/* fork process two here */
	switch (pid2 = fork()) {
		case -1:
			perror("fork");
			exit(1);
		case 0:
			process2();
			return 0;
		default: 
			break;
	}
	
	/* parent waits (use wait();) for child processes to finish. */
	wait(NULL);
	wait(NULL);
	/* parent process reports value of counter */
	/* parent process exits safely */
	
	/*deallocate shared memory */
	if(shmctl(shmid, IPC_RMID, (struct shmid_ds *)0)== -1){
	    perror("shmctl");
	    exit(-1);
	}
	


	stop = clock();
	elapsed = ( (double)(stop - start) ) / CLOCKS_PER_SEC;
	fprintf(OUT, "Parent finished in %.8f seconds. Value of counter: %d\n", elapsed, counter->value);
	exit(0);

}
