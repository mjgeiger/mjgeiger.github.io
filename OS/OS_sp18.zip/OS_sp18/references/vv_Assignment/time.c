#include <stdio.h>
#include <time.h>

main(){
clock_t         start, stop;
double          elapsed;
int i;


 start = clock();
 
/* the algorithm goes here */

 stop = clock();

 elapsed =((double) (stop - start))/CLOCKS_PER_SEC;
 
 fprintf(stderr,"Elapsed time = %lf\n", elapsed);

}
