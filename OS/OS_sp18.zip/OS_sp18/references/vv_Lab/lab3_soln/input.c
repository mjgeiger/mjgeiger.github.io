#include "smallsh.h"
static char inpbuf[MAXBUF], tokbuf[2*MAXBUF], *ptr = inpbuf, *tok = tokbuf;


static char special[] = {' ', '\t', '&', ';', '\n','<', '>', '\0' };
int inarg(char c)
{
	char *wrk;

	for (wrk = special; *wrk; wrk++)
	{
		if (c == *wrk)
			return (0);
	}
	return 1;
}

int userin()
{
	char cwd[DIRSIZE];
	int len;
	int c, count;
	ptr = inpbuf;
	tok = tokbuf;

	if ( getcwd(cwd, DIRSIZE) == NULL)
	{
		perror("smallsh");
		strcpy(cwd, "smallsh");
	}

	//append $to the prompt
	len = strlen(cwd);

	cwd[len] = '$';
	cwd[len+1]= ' ';
	cwd[len+2] = '\0';

	//prints the prompt
	printf("%s", cwd);
	count = 0;

	while(1)
	{

		if ( (c=getchar()) == EOF)
			return (EOF);

		if (count < MAXBUF)
			inpbuf[count++] = c;

		if (c == '\n' && count < MAXBUF)
		{
			inpbuf[count] = '\0';
			return count;
		}

		if (c == '\n')
		{
			printf("smallsh: input line too long\n");
			count = 0;
			printf("%s", cwd);
		}
	}
}

int gettok(char **outptr) 
{
	int type;
	
	*outptr = tok;

	while (*ptr == ' ' || *ptr == '\t')
		ptr++;

	*tok++ = *ptr;

	switch(*ptr++) {
	case '\n':
		type = EOL;
		break;
	case '&':
		type = AMPERSAND;
		break;
	case ';':
		type = SEMICOLON;
		break;
	case '<':
		type = REDIRECTIN;
		break;
	case '>':
		type = REDIRECTOUT;
		break;

	default:
		type = ARG;

		while(inarg(*ptr))
			*tok++ = *ptr++;
	}

	*tok++ = '\0';
	return type;
}



