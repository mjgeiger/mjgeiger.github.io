#include "smallsh.h"

int procline(void)
{
	char *arg[MAXARG + 1];
	char filebuf[100], *file;
	int toktype;
	int narg;
	int type;

	narg = 0;

	for (;;) 
	{
		file = filebuf;
		switch (toktype=gettok(&arg[narg])) {
		case ARG: if (narg < MAXARG)
				narg++;
			  break;
		case EOL:
		case SEMICOLON:
		case AMPERSAND:
		case REDIRECTIN:
		case REDIRECTOUT:
			if ( toktype == AMPERSAND)
				type = BACKGROUND;
			else 
				type = FOREGROUND;
			
			file = "";
			if (toktype == REDIRECTOUT || toktype == REDIRECTIN)
			{
				
				gettok(&file);
			}

			
			if (narg != 0)
			{
				arg[narg] = NULL;
				runcommand(arg, type,file, toktype);
			}

			if (toktype == EOL)
				return;

			narg = 0;
			break;
		}

	}
	


}

