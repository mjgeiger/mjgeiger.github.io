#include "smallsh.h"
#include <sys/types.h>
#include <fcntl.h>

int runcommand(char **cline, int where, char *file, int redir)
{
	pid_t pid;
	int status, oldfd;
	
	//check for the cd command
	if (strcmp(*cline, "cd") == 0)
	{
		if (chdir(cline[1]) == -1)
		{
			perror("smallsh");
		}			
		return 0;
	}	

	//check for the exit command
	if (strcmp(*cline, "exit") == 0)
	{
		exit(1);	
	}


	switch (pid = fork()) {
	case -1:
		perror("smallsh");
		return (-1);
	case 0:
	
		//file holds the file to redirect from/to. it is set to "" unless
		//the user specified a redirct command
		if (strcmp(file, "") != 0)
		{
			//if it is to redirect output, duplicate stdout
			if (redir == REDIRECTOUT) 
			{
				oldfd = open(file, O_RDWR | O_CREAT, 0644);
				dup2(oldfd, 1);
			}
			//if it is to redirect input, duplicate stdin
			else if (redir == REDIRECTIN)
			{
				if ( (oldfd = open(file, O_RDONLY)) != -1)
				{
					dup2(oldfd, 0);
				}
				else
				{
					perror("smallsh");
					exit(1); //just kills child, not smallsh
				}
			}

		}
	
		execvp(*cline, cline);
		perror(*cline);
		exit(1);
	}

	

	
	if (where == BACKGROUND)
	{
		printf("[Process id %d]\n", pid);
		return 0;
	}
	if (waitpid(pid, &status, 0) == -1)
		return (-1);
	else
		return status;


}
