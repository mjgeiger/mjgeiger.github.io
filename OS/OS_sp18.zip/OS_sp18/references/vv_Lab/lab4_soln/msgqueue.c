/*
*
*  Neal Charbonneau CIS 370 Lab4
*
*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>
#define MAX_SEND_SIZE 1024

struct mymsgbuf {
        long mtype;
        char mtext[MAX_SEND_SIZE];
};

void send_message(int qid, struct mymsgbuf *qbuf, long type, char *text);
void read_message(int qid, struct mymsgbuf *qbuf, long type);
void remove_queue(int qid);
void change_queue_mode(int qid, char *mode);
void usage(void);


int main(int argc, char *argv[])
{
        key_t key;
	int   msgqueue_id;
        struct mymsgbuf qbuf;

        if(argc == 1)
                usage();

        /* Create unique key via call to ftok() */
      	if ((key = ftok("/etc/", 'n')) == -1) 
	{
		perror("MQueue: ");
		exit(1);
	} 
        /* Open the queue - create if necessary */
	if ((msgqueue_id = msgget(key, IPC_CREAT | 0660)) == -1)
	{
		perror("MQueue create");
		exit(1);
	}

        	
        switch(tolower(argv[1][0]))
        {
        	case 's': 
			printf("Sending message...\n");
			send_message(msgqueue_id, &qbuf,atol(argv[2]), argv[3]);			 
                        break;
                case 'r': 
			printf("Reading a message...\n");
			 
			read_message(msgqueue_id, &qbuf,atol(argv[2]));
	 		printf("Type: %d  Text: %s\n",qbuf.mtype, qbuf.mtext);
                        break;
                case 'd': /***** remove the queue *****/ 
			remove_queue(msgqueue_id);
                        break;          
                case 'm': /***** change the queue mode *****/ 
			change_queue_mode(msgqueue_id, argv[2]);
                        break;

                default: usage();
        }
        
        return(0);
}

void send_message(int qid, struct mymsgbuf *qbuf, long type, char *text)
{
	int length;
	qbuf->mtype = type;
	strcpy(qbuf->mtext, text);	

	//get the number of bytes the string is taking up (+1 for null char)
	length = (strlen(qbuf->mtext) + 1) * sizeof(char);

	if( (msgsnd(qid, (struct msgbuf *)qbuf, length, 0)) == -1)
	{
		perror("Error sending");
		exit(1);
	}
}

void read_message(int qid, struct mymsgbuf *qbuf, long type)
{	
	int result, length;

	length = sizeof(struct mymsgbuf) - sizeof(long);

	if (msgrcv(qid, (struct msgbuf*)qbuf, length, type, 0) == -1)
	{
		perror("Reading");
		exit(1);
	}
}

void remove_queue(int qid)
{
	if (msgctl(qid, IPC_RMID, 0) == -1)
	{
		perror("delete");
		exit(1);
	}
}

void change_queue_mode(int qid, char *mode)
{
	struct msqid_ds buf;
	if (msgctl(qid, IPC_STAT, &buf) == -1)
	{
		printf("errno %d\n", errno);
		exit(1);
	}	

	sscanf(mode, "%ho", &buf.msg_perm.mode);

	if (msgctl(qid, IPC_SET, &buf) == -1)
	{
		perror("set stat");
		exit(1);
	}
}

void usage(void)
{
	printf("msgqueue : A tool for tinkering with msg queues\n\n");
	printf("USAGE: msgtool (s)end <type> <messagetext>\n");
	printf("\t(r)ecv <type>\n");
	printf("\t(d)elete\n");
	printf("\t(m)ode <octal mode>\n");
	exit(0);

 
}
