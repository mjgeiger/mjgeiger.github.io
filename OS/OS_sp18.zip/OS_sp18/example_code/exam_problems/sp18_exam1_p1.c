//
//  sp18_exam1_p1.c
//  
//  EECE.4810/5730
//  Dr. Michael Geiger
//  2/19/18
//	Example code for first exam, Problem 1
//  Multi-process program example
//   Initial process
//

#include <sys/types.h>
#include <sys/wait.h>		// Necessary on my Mac for wait() function
#include <stdio.h>
#include <unistd.h>
#include <stdio.h>

int var1 = 10;

int main() {
	int var2 = 20;
	char str[10];
	pid_t pid;
	
	pid = fork();
	if (pid == 0) {
		var1 = 30;
		var2 = 40;
	}

	pid = fork();
	if (pid == 0) {
		sprintf(str, "%d", var1 + var2);
		execlp("./exam1pr2", "exam1pr2", str, NULL);
	}
	else if (pid > 0) {
		wait(NULL);
		printf("P1 parent: %d %d\n", var1, var2);
	}
	return 0;
}
