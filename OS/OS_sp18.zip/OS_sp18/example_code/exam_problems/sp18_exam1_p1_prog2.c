//
//  sp18_exam1_p1_prog2.c
//  
//  EECE.4810/5730
//  Dr. Michael Geiger
//  2/19/18
//	Example code for first exam, Problem 1
//  Multi-process program example
//    Secondary process
//

#include <sys/types.h>
#include <sys/wait.h>		// Necessary on my Mac for wait() function
#include <stdio.h>
#include <unistd.h>
#include <stdio.h>

int main(int argc, char **argv) {
	pid_t pid = fork();
	if (pid == 0)
		printf("P2 child: %s\n", argv[1]);
	else if (pid > 0) {
		wait(NULL);
		printf("P2 parent: %s\n", argv[1]);
	}
	return 0;
}
