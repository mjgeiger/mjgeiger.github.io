//
//  lec7_shared_queue_skeletons.c
//  
//
//  Created by Michael Geiger on 2/14/18.
//
//
//  Skeleton code to be used in thread-safe queue example
//  Adapted from UMich OS examples (which are themselves likely
//   adapted from Anderson & Dahlin OS:PP text)

// node definition--assumes first node in queue is "dummy node"
struct node {
	int data;
	struct node *next;
}

// queue structure definition
struct queue {
	struct node *head;
}

// Skeleton code for enqueue V1--no synchronization
void enqueue(struct node *new_element) {
	// Find queue tail
	for (ptr = head; ptr->next != NULL; ptr = ptr->next) {}
	
	// Add new element to tail
	ptr->next = new_element;
	new_element->next = NULL;
}

// Skeleton code for dequeue V1--no synchronization
struct node *dequeue() {
	struct node *elem = NULL;

	// If queue not empty, remove first node
	if (head->next != NULL) {
		elem = head->next;
		head->next = head->next->next;
	}
	return elem;
}

// Skeleton code for dequeue V2/V3--waits if empty but doesn't work right
struct node *dequeue() {
	struct node *elem = NULL;
	qmutex.lock();
	
	// Wait for queue to not be empty
	qmutex.unlock();
	while (head->next == NULL);
	qmutex.lock();		// NO GUARANTEE QUEUE WILL STILL BE EMPTY WHEN YOU LOCK AGAIN
	
	// Remove element
	elem = head->next;
	head->next = head->next->next;

	qmutex.unlock();
	return elem;
}