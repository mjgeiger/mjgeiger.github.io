/*
 * 16.216: ECE Application Programming, University of Massachusetts Lowell
 * Instructor: Dr. Michael Geiger
 *
 * 10/30/11: Programming Exercise 4
 * Program is intended to give students practice with functions, pointer arguments
 *
 * Given any amount of change under $2.00, determine and print minimum 
 *  number of coins required to make that change.
 * Assume available coins are: half dollars ($0.50 each), quarters ($0.25 each)
 *  dimes ($0.10 each), nickels ($0.05 each), and pennies ($0.01 each)
 */

#include <stdio.h>

/* FUNCTION PROTOTYPE--THIS PROGRAM SHOULD USE ONE FUNCTION, TO BE DEFINED
   DURING EXERCISE (SEE LECTURE NOTES IF YOU CAN'T MAKE CLASS) */

int main() {
	/* VARIABLE DECLARATIONS */

	/* CALCULATE NUMBER OF EACH TYPE OF COIN TO BE USED */

	/* PRINT FINAL RESULTS */

	return 0;
}

/* FUNCTION DEFINITION--SEE PROTOTYPE ABOVE */